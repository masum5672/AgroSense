import os, glob

pwa_tags = """  <!-- PWA & Mobile Meta Tags -->
  <link rel="manifest" href="/manifest.json">
  <meta name="theme-color" content="#00c785">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="AgroSense">
  <link rel="apple-touch-icon" href="/assets/images/logo.png">
"""

for root, _, files in os.walk('d:/smart_farming'):
    if 'node_modules' in root or '.firebase' in root:
        continue
    for file in files:
        if file.endswith('.html') and file != 'index.html':
            filepath = os.path.join(root, file)
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            if 'rel="manifest"' not in content and '</head>' in content:
                new_content = content.replace('</head>', pwa_tags + '</head>')
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                print(f"Added PWA tags to {filepath}")

print("Done updating HTML files with PWA tags.")
