/**
 * app.js
 * AgroSense — Main Application Entry Point
 * 
 * Handles:
 *  - Auth guard for all protected pages
 *  - Sidebar toggle / collapse
 *  - Active nav item detection
 *  - Page loader
 *  - Theme initialization
 *  - User info in topbar/sidebar
 */

import { onAuthChange, getCurrentUser, signOutUser, getUserInitials } from './firebase/auth.js';
import { DEMO_MODE }    from './firebase/firebaseConfig.js';
import { applyTheme, toggleTheme }   from './modules/utils.js';
import { showToast }    from './modules/notification.js';

// ─── PAGE LOADER ──────────────────────────────────────────────────────────────

export function hideLoader() {
  const loader = document.getElementById('page-loader');
  if (loader) {
    loader.classList.add('hidden');
  }
}

// Service Worker Registration for PWA Support
if (typeof window !== 'undefined') {
  window.addEventListener('DOMContentLoaded', () => {
    setTimeout(hideLoader, 2500);

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js')
        .then(reg => console.log('[PWA] Service Worker registered:', reg.scope))
        .catch(err => console.warn('[PWA] Service Worker registration failed:', err));
    }
  });
}

export function showLoader() {
  const loader = document.getElementById('page-loader');
  if (loader) loader.classList.remove('hidden');
}

// ─── INIT APP ────────────────────────────────────────────────────────────────

/**
 * Initialize the app shell (sidebar, topbar, theme).
 * Call this on every protected page.
 * @param {object} [options]
 * @param {string} [options.pageId]     - active nav item ID
 * @param {boolean} [options.requireAuth=true]
 */
export async function initApp(options = {}) {
  const { pageId = null, requireAuth: doAuth = true } = options;

  try {
    // 1. Apply saved theme
    applyTheme();

    // 2. Auth guard (max 2 seconds timeout)
    if (!DEMO_MODE && doAuth) {
      await Promise.race([
        waitForAuth(),
        new Promise(resolve => setTimeout(resolve, 2000))
      ]);
    }

    // 3. Populate user info
    populateUserInfo();

    // 4. Sidebar & Device Status
    initSidebar(pageId);
    listenGlobalDeviceStatus();

    // 5. Topbar bindings
    initTopbar();
  } catch (err) {
    console.error('[App Init Error]', err);
  } finally {
    // 6. ALWAYS hide loader
    hideLoader();
  }
}

// ─── AUTH GUARD ───────────────────────────────────────────────────────────────

function waitForAuth() {
  return new Promise(resolve => {
    const unsub = onAuthChange(user => {
      unsub();
      if (!user) {
        // Redirect to login page if unauthenticated
        const isSubPage = window.location.pathname.includes('/pages/');
        const target = isSubPage ? '../login.html' : 'login.html';
        if (!window.location.pathname.endsWith('login.html')) {
          window.location.href = target;
        }
      } else {
        resolve(user);
      }
    });
  });
}

// ─── USER INFO ────────────────────────────────────────────────────────────────

function populateUserInfo() {
  const user      = getCurrentUser();
  const initials  = DEMO_MODE ? 'SF' : (user ? getUserInitials(user) : 'SF');
  const name      = DEMO_MODE ? 'Demo User' : (user?.displayName || user?.email || 'Farmer');
  const email     = DEMO_MODE ? 'demo@smartfarm.io' : (user?.email || '');

  // Avatar initials
  document.querySelectorAll('.user-avatar-initials').forEach(el => el.textContent = initials);
  document.querySelectorAll('.user-display-name').forEach(el => el.textContent = name);
  document.querySelectorAll('.user-email').forEach(el => el.textContent = email);
}

// ─── SIDEBAR ─────────────────────────────────────────────────────────────────

function initSidebar(activePageId) {
  const sidebar       = document.getElementById('sidebar');
  const overlay       = document.getElementById('sidebar-overlay');
  const toggleDesktop = document.getElementById('sidebar-toggle-desktop');
  const toggleMobile  = document.getElementById('sidebar-toggle-mobile');

  if (!sidebar) return;

  // Restore collapsed state
  const isCollapsed = localStorage.getItem('sf_sidebar_collapsed') === '1';
  if (isCollapsed) {
    sidebar.classList.add('collapsed');
    document.querySelector('.main-content')?.classList.add('sidebar-collapsed');
  }

  // Desktop toggle (collapse/expand)
  toggleDesktop?.addEventListener('click', () => {
    const collapsed = sidebar.classList.toggle('collapsed');
    document.querySelector('.main-content')?.classList.toggle('sidebar-collapsed', collapsed);
    localStorage.setItem('sf_sidebar_collapsed', collapsed ? '1' : '0');
  });

  // Mobile toggle
  toggleMobile?.addEventListener('click', () => {
    sidebar.classList.toggle('mobile-open');
    overlay?.classList.toggle('active');
  });

  // Close on overlay click
  overlay?.addEventListener('click', () => {
    sidebar.classList.remove('mobile-open');
    overlay.classList.remove('active');
  });

  // Set active nav item
  if (activePageId) {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.page === activePageId);
    });
  }

  // Logout buttons
  document.querySelectorAll('.btn-logout').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      await signOutUser();
    });
  });
}

// ─── CLOCK ────────────────────────────────────────────────────────────────────

function startClock() {
  function tick() {
    const now = new Date();
    const timeEl = document.getElementById('clock-time');
    const dateEl = document.getElementById('clock-date');

    if (timeEl) {
      timeEl.textContent = now.toLocaleTimeString('en-US', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      });
    }
    if (dateEl) {
      dateEl.textContent = now.toLocaleDateString('en-US', {
        weekday: 'short', month: 'short', day: 'numeric'
      });
    }
  }
  tick();
  setInterval(tick, 1000);
}

// ─── TOPBAR ───────────────────────────────────────────────────────────────────

function initTopbar() {
  // Start live clock on every page
  startClock();

  // Theme toggle button
  const themeBtn = document.getElementById('theme-toggle-btn');
  if (themeBtn) {
    const updateIcon = (theme) => {
      const icon = themeBtn.querySelector('i');
      if (icon) icon.className = theme === 'dark' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
    };

    const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
    updateIcon(currentTheme);

    themeBtn.addEventListener('click', () => {
      const newTheme = toggleTheme();
      updateIcon(newTheme);
    });
  }

  // Notification bell
  const notifBtn   = document.getElementById('notification-btn');
  const notifPanel = document.getElementById('notification-panel');
  notifBtn?.addEventListener('click', () => {
    notifPanel?.classList.toggle('open');
  });
}

// ─── ESP32 DEVICE STATUS LISTENER ─────────────────────────────────────────────

let _globalLastKnownTs = 0;

function updateGlobalDeviceStatusUI(ts) {
  const nowSec = Math.floor(Date.now() / 1000);
  const diffSec = ts > 1e11 ? Math.abs(Date.now() - ts) / 1000 : Math.abs(nowSec - ts);
  const isOnline = (ts > 0 && diffSec < 35);

  document.querySelectorAll('.device-status-dot').forEach(dot => {
    dot.className = `status-dot ${isOnline ? 'online' : 'offline'} device-status-dot`;
  });
  const sidebarValEl = document.getElementById('sidebar-device-value');
  if (sidebarValEl) sidebarValEl.textContent = isOnline ? 'Online' : 'Offline';
  const labelEl = document.getElementById('topbar-device-label');
  if (labelEl) labelEl.textContent = isOnline ? 'ESP32 Online' : 'ESP32 Offline';
}

function listenGlobalDeviceStatus() {
  // Dynamically import database and firebaseConfig to avoid circular dependencies
  import('./firebase/database.js').then(({ listenToPath }) => {
    import('./firebase/firebaseConfig.js').then(({ DB_PATHS }) => {
      listenToPath(DB_PATHS.DEVICE, (data) => {
        if (!data) return;
        const ts = typeof data.lastUpdate === 'number' ? data.lastUpdate : (data.timestamp || 0);
        _globalLastKnownTs = ts;
        updateGlobalDeviceStatusUI(ts);
      }, 'global-device-status');

      setInterval(() => {
        if (_globalLastKnownTs > 0) {
          updateGlobalDeviceStatusUI(_globalLastKnownTs);
        }
      }, 5000);

    });
  }).catch(err => console.warn('[Device Status Listener Error]', err));
}

// ─── ADMIN SETUP UTILITY ──────────────────────────────────────────────────────
window.claimAdmin = async function() {
  const { auth } = await import('./firebase/auth.js');
  const user = auth.currentUser;
  if (!user) return console.error('You must be logged in to claim admin.');
  
  try {
    const { ref, set } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js');
    const { database } = await import('./firebase/firebaseConfig.js');
    await set(ref(database, `users/${user.uid}`), {
      role: 'admin',
      secret: 'CLAIM_ADMIN_SECRET_123' // Required by our temporary security rule
    });
    console.log('✅ Success! Your account is now an Admin. Please refresh the page.');
    alert('Success! Your account is now an Admin. Please refresh the page.');
  } catch (e) {
    console.error('❌ Failed to claim admin:', e);
    alert('Failed to claim admin: ' + e.message);
  }
};

export function showDemoBanner() {
  if (!DEMO_MODE) return;
  const banner = document.getElementById('demo-banner');
  if (banner) banner.style.display = 'flex';
}

