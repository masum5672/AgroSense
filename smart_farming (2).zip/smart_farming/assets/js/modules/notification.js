/**
 * notification.js
 * AgroSense — Toast Notification System
 * 
 * Usage:
 *   showToast('Title', 'Message', 'success' | 'warning' | 'danger' | 'info')
 *   showAlert(type)  — predefined AgroSense alerts
 */

// ─── CONTAINER ────────────────────────────────────────────────────────────────

let container = null;

function ensureContainer() {
  if (!container) {
    container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      document.body.appendChild(container);
    }
  }
  return container;
}

// ─── ICONS MAP ────────────────────────────────────────────────────────────────

const ICONS = {
  success: 'fa-circle-check',
  warning: 'fa-triangle-exclamation',
  danger:  'fa-circle-xmark',
  info:    'fa-circle-info',
};

// ─── MAIN TOAST FUNCTION ──────────────────────────────────────────────────────

let toastQueue  = [];
let activeCount = 0;
const MAX_VISIBLE = 5;

/**
 * Show a toast notification.
 * @param {string} title    - Toast title
 * @param {string} message  - Toast body text
 * @param {'success'|'warning'|'danger'|'info'} type - Visual style
 * @param {number} [duration=4500] - Auto-dismiss delay in ms (0 = no auto-dismiss)
 */
export function showToast(title, message, type = 'info', duration = 4500) {
  if (activeCount >= MAX_VISIBLE) {
    toastQueue.push({ title, message, type, duration });
    return;
  }

  activeCount++;
  const c    = ensureContainer();
  const icon = ICONS[type] || ICONS.info;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <div class="toast-accent"></div>
    <div class="toast-icon"><i class="fa-solid ${icon}"></i></div>
    <div class="toast-body">
      <div class="toast-title">${escapeHTML(title)}</div>
      <div class="toast-message">${escapeHTML(message)}</div>
    </div>
    <button class="toast-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
    ${duration > 0 ? '<div class="toast-progress"></div>' : ''}
  `;

  // Close button
  toast.querySelector('.toast-close').addEventListener('click', () => dismissToast(toast));
  toast.addEventListener('click', () => dismissToast(toast));

  c.appendChild(toast);

  // Progress bar animation
  if (duration > 0) {
    const progressEl = toast.querySelector('.toast-progress');
    progressEl.style.width = '100%';
    progressEl.style.transition = `width ${duration}ms linear`;
    // Trigger reflow
    void progressEl.offsetWidth;
    progressEl.style.width = '0%';

    // Auto dismiss
    setTimeout(() => dismissToast(toast), duration);
  }

  return toast;
}

/**
 * Dismiss and remove a toast element.
 * @param {HTMLElement} toast
 */
function dismissToast(toast) {
  if (toast._dismissed) return;
  toast._dismissed = true;
  toast.classList.add('hiding');
  toast.addEventListener('animationend', () => {
    toast.remove();
    activeCount = Math.max(0, activeCount - 1);
    // Process queue
    if (toastQueue.length > 0) {
      const next = toastQueue.shift();
      showToast(next.title, next.message, next.type, next.duration);
    }
  }, { once: true });
}

// ─── PREDEFINED AgroSense ALERTS ─────────────────────────────────────────

const SMART_ALERTS = {
  pumpOn:       { title: '💧 Pump Started',    message: 'Water pump is now running.',           type: 'success' },
  pumpOff:      { title: '⏹ Pump Stopped',    message: 'Water pump has been turned off.',       type: 'info'    },
  soilDry:      { title: '🌱 Soil Dry Alert',  message: 'Soil moisture is below threshold!',    type: 'warning' },
  rainDetected: { title: '🌧 Rain Detected',   message: 'Rain sensor triggered. Pump paused.', type: 'info'    },
  waterLow:     { title: '🚨 Tank Empty!',     message: 'Water level critically low.',          type: 'danger'  },
  esp32Offline: { title: '📡 Device Offline',  message: 'ESP32 is not responding.',             type: 'danger'  },
  esp32Online:  { title: '✅ Device Online',   message: 'ESP32 is connected and live.',         type: 'success' },
  settingsSaved:{ title: '✅ Settings Saved',  message: 'Your settings have been updated.',     type: 'success' },
  autoMode:     { title: '🤖 Auto Mode On',    message: 'Pump will activate automatically.',   type: 'info'    },
  manualMode:   { title: '🖐 Manual Mode',     message: 'You are in manual pump control.',     type: 'info'    },
  tempHigh:     { title: '🌡 High Temperature',message: 'Temperature exceeds threshold!',       type: 'warning' },
  loginSuccess: { title: '👋 Welcome Back!',   message: 'Signed in successfully.',              type: 'success' },
};

/**
 * Show a predefined AgroSense alert.
 * @param {keyof SMART_ALERTS} alertKey
 */
export function showAlert(alertKey) {
  const alert = SMART_ALERTS[alertKey];
  if (!alert) return;
  showToast(alert.title, alert.message, alert.type);
}

// ─── NOTIFICATION HISTORY ─────────────────────────────────────────────────────

const notificationHistory = [];

/**
 * Log a notification to the history panel.
 * @param {string} title
 * @param {string} message
 * @param {string} type
 */
export function logNotification(title, message, type = 'info') {
  notificationHistory.unshift({
    title,
    message,
    type,
    timestamp: Date.now(),
    read: false,
  });

  // Cap at 50 notifications
  if (notificationHistory.length > 50) notificationHistory.pop();

  // Update badge
  updateNotificationBadge();
  showToast(title, message, type);
}

function updateNotificationBadge() {
  const unread = notificationHistory.filter(n => !n.read).length;
  const badge  = document.querySelector('.notification-dot');
  if (badge) {
    badge.style.display = unread > 0 ? 'block' : 'none';
  }
}

/**
 * Get notification history.
 * @returns {object[]}
 */
export function getNotificationHistory() {
  return notificationHistory;
}

/**
 * Mark all notifications as read.
 */
export function markAllRead() {
  notificationHistory.forEach(n => n.read = true);
  updateNotificationBadge();
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────

function escapeHTML(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}
