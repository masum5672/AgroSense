/**
 * utils.js
 * AgroSense — Shared Utility Functions
 * Updated for exact hardware sensor IDs
 */

// ─── THEME ────────────────────────────────────────────────────────────────────
export function applyTheme() {
  const saved = localStorage.getItem('sf_theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  return saved;
}

export function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const next    = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('sf_theme', next);
  return next;
}

// ─── SENSOR STATUS ────────────────────────────────────────────────────────────
// Maps each sensor ID to human-readable status + color
export function getSensorStatus(id, value) {
  const v = parseFloat(value);
  const map = {
    temperature: [
      { max: 10,  label: 'Too Cold',  level: 'danger',  color: '#3b82f6' },
      { max: 35,  label: 'Normal',    level: 'normal',  color: '#00c785' },
      { max: Infinity, label: 'Too Hot',  level: 'danger',  color: '#ef4444' },
    ],
    humidity: [
      { max: 30,  label: 'Too Dry',   level: 'warning', color: '#eab308' },
      { max: 80,  label: 'Normal',    level: 'normal',  color: '#00c785' },
      { max: Infinity, label: 'Too Humid', level: 'warning', color: '#06b6d4' },
    ],
    soilMoisture: [
      { max: 30,  label: 'Dry',       level: 'danger',  color: '#ef4444' },
      { max: 70,  label: 'Good',      level: 'normal',  color: '#00c785' },
      { max: Infinity, label: 'Saturated', level: 'warning', color: '#3b82f6' },
    ],
    soilTemperature: [
      { max: 10,  label: 'Too Cold',  level: 'warning', color: '#3b82f6' },
      { max: 30,  label: 'Optimal',   level: 'normal',  color: '#00c785' },
      { max: Infinity, label: 'Too Hot',  level: 'danger',  color: '#ef4444' },
    ],
    rain: [
      { max: 10,  label: 'No Rain',   level: 'normal',  color: '#00c785' },
      { max: 50,  label: 'Light Rain',level: 'warning', color: '#06b6d4' },
      { max: Infinity, label: 'Heavy Rain', level: 'danger',  color: '#3b82f6' },
    ],
    light: [
      { max: 200,  label: 'Dark',     level: 'warning', color: '#eab308' },
      { max: 900,  label: 'Normal',   level: 'normal',  color: '#00c785' },
      { max: Infinity, label: 'Bright', level: 'warning', color: '#f97316' },
    ],
    waterLevel: [
      { max: 20,  label: 'Critical',  level: 'danger',  color: '#ef4444' },
      { max: 60,  label: 'Low',       level: 'warning', color: '#eab308' },
      { max: Infinity, label: 'Adequate', level: 'normal',  color: '#00c785' },
    ],
  };

  const thresholds = map[id];
  if (!thresholds) return { label: 'Unknown', level: 'normal', color: '#00c785' };
  for (const t of thresholds) {
    if (v < t.max) return t;
  }
  return thresholds[thresholds.length - 1];
}

// ─── SENSOR PERCENT ───────────────────────────────────────────────────────────
export function getSensorPercent(id, value) {
  const ranges = {
    temperature:     { min: 0, max: 50 },
    humidity:        { min: 0, max: 100 },
    soilMoisture:    { min: 0, max: 100 },
    soilTemperature: { min: 0, max: 50 },
    rain:            { min: 0, max: 100 },
    light:           { min: 0, max: 1200 },
    waterLevel:      { min: 0, max: 100 },
  };
  const r = ranges[id] || { min: 0, max: 100 };
  return Math.min(100, Math.max(0, ((value - r.min) / (r.max - r.min)) * 100));
}

// ─── FORMAT UPTIME ────────────────────────────────────────────────────────────
export function formatUptime(seconds) {
  const s = parseInt(seconds) || 0;
  if (s < 60)   return `${s}s`;
  if (s < 3600) return `${Math.floor(s/60)}m ${s%60}s`;
  const h = Math.floor(s/3600);
  const m = Math.floor((s%3600)/60);
  return `${h}h ${m}m`;
}

// ─── WIFI QUALITY (uses wifiRSSI from device) ─────────────────────────────────
export function wifiQuality(rssi) {
  const r = parseInt(rssi) || 0;
  if (r >= -50) return { label: `Excellent (${r}dBm)`, level: 'excellent' };
  if (r >= -60) return { label: `Good (${r}dBm)`,      level: 'good'      };
  if (r >= -70) return { label: `Fair (${r}dBm)`,      level: 'fair'      };
  return { label: `Weak (${r}dBm)`, level: 'weak' };
}

// ─── ANIMATE NUMBER ───────────────────────────────────────────────────────────
export function animateNumber(el, from, to, suffix = '', decimals = 0) {
  if (!el) return;
  const diff     = to - from;
  const duration = 600;
  const steps    = 30;
  let   step     = 0;
  const timer = setInterval(() => {
    step++;
    const progress = step / steps;
    const eased    = 1 - Math.pow(1 - progress, 3);
    const current  = from + diff * eased;
    el.textContent = current.toFixed(decimals) + suffix;
    if (step >= steps) {
      clearInterval(timer);
      el.textContent = to.toFixed(decimals) + suffix;
    }
  }, duration / steps);
}

// ─── DATE KEY ─────────────────────────────────────────────────────────────────
export function toDateKey(date = new Date()) {
  return date.toISOString().split('T')[0];
}

// ─── CSV EXPORT ───────────────────────────────────────────────────────────────
export function downloadCSV(rows, columns, filename) {
  const header = columns.join(',');
  const body   = rows.map(r => columns.map(c => JSON.stringify(r[c] ?? '')).join(',')).join('\n');
  const blob   = new Blob([header + '\n' + body], { type: 'text/csv' });
  const url    = URL.createObjectURL(blob);
  const a      = Object.assign(document.createElement('a'), { href: url, download: filename });
  a.click();
  URL.revokeObjectURL(url);
}
