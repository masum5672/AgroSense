/**
 * charts.js
 * AgroSense — Chart.js Module
 * Updated for 7 sensors: temperature, humidity, soilMoisture, soilTemperature, rain, light, waterLevel
 */

import { getLatestHistory, getHistory } from '../firebase/database.js';
import { DB_PATHS }                     from '../firebase/firebaseConfig.js';

const chartInstances = {};

const SENSOR_COLORS = {
  temperature:     '#f97316',
  humidity:        '#3b82f6',
  soilMoisture:    '#00c785',
  soilTemperature: '#d97706',
  rain:            '#06b6d4',
  light:           '#eab308',
  waterLevel:      '#8b5cf6',
};

const SENSOR_LABELS = {
  temperature:     'Temperature (°C)',
  humidity:        'Humidity (%)',
  soilMoisture:    'Soil Moisture (%)',
  soilTemperature: 'Soil Temperature (°C)',
  rain:            'Rain Sensor (%)',
  light:           'Light Intensity (lux)',
  waterLevel:      'Water Level (%)',
};

// ─── CHART DEFAULTS ───────────────────────────────────────────────────────────
function getChartDefaults(color, label) {
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  return {
    type: 'line',
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: isDark ? '#1e293b' : '#fff',
          titleColor: isDark ? '#94a3b8' : '#475569',
          bodyColor:  isDark ? '#f0f4ff'  : '#0f172a',
          borderColor: color, borderWidth: 1,
          padding: 10,
        },
      },
      scales: {
        x: {
          grid:   { color: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' },
          ticks:  { color: isDark ? '#64748b' : '#94a3b8', maxTicksLimit: 8, font: { size: 10 } },
        },
        y: {
          grid:   { color: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' },
          ticks:  { color: isDark ? '#64748b' : '#94a3b8', font: { size: 10 } },
        },
      },
      animation: { duration: 400 },
      elements: {
        line:  { tension: 0.4, borderWidth: 2 },
        point: { radius: 2, hoverRadius: 5 },
      },
    },
  };
}

function buildDataset(label, data, color) {
  return {
    label,
    data,
    borderColor:     color,
    backgroundColor: hexToRgba(color, 0.1),
    fill: true,
    tension: 0.4,
    borderWidth: 2,
    pointRadius: 2,
  };
}

// ─── REALTIME ROLLING CHART ───────────────────────────────────────────────────
// Listens to sf:sensors events and pushes rolling data points
export function initRealtimeChart(canvasId, sensorId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const color    = SENSOR_COLORS[sensorId] || '#00c785';
  const label    = SENSOR_LABELS[sensorId] || sensorId;
  const labels   = [];
  const data     = [];
  const MAX_PTS  = 30;

  if (chartInstances[canvasId]) {
    chartInstances[canvasId].destroy();
    delete chartInstances[canvasId];
  }

  const defaults = getChartDefaults(color, label);
  const chart    = new Chart(canvas.getContext('2d'), {
    ...defaults,
    data: { labels, datasets: [buildDataset(label, data, color)] },
  });
  chartInstances[canvasId] = chart;

  window.addEventListener('sf:sensors', (e) => {
    const sensors = e.detail;
    const val     = parseFloat(sensors[sensorId] ?? 0);
    const time    = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

    labels.push(time);
    data.push(val);
    if (labels.length > MAX_PTS) { labels.shift(); data.shift(); }
    chart.update('none');
  });

  return chart;
}

// ─── HISTORICAL CHART ─────────────────────────────────────────────────────────
export async function loadHistoricalChart(canvasId, sensorId, range = '24h', customRange = null) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const color = SENSOR_COLORS[sensorId] || '#00c785';
  const label = SENSOR_LABELS[sensorId] || sensorId;

  let startDate, endDate;
  const now   = new Date();
  if (customRange) {
    startDate = customRange.start;
    endDate   = customRange.end;
  } else {
    const d = new Date(now);
    if (range === '7d')  d.setDate(d.getDate() - 7);
    if (range === '30d') d.setDate(d.getDate() - 30);
    startDate = d.toISOString().split('T')[0];
    endDate   = now.toISOString().split('T')[0];
  }

  const rawData = await getHistory(startDate, endDate);
  const rows    = flattenHistory(rawData);

  const step = Math.max(1, Math.floor(rows.length / 60));
  const filtered = rows.filter((_, i) => i % step === 0).slice(-120);

  const chartLabels = filtered.map(r => new Date(r.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }));
  const chartData   = filtered.map(r => parseFloat(r[sensorId] ?? 0));

  if (chartInstances[canvasId]) {
    chartInstances[canvasId].destroy();
    delete chartInstances[canvasId];
  }

  const defaults = getChartDefaults(color, label);
  chartInstances[canvasId] = new Chart(canvas.getContext('2d'), {
    ...defaults,
    data: { labels: chartLabels, datasets: [buildDataset(label, chartData, color)] },
  });

  return chartInstances[canvasId];
}

// ─── OVERVIEW CHART ───────────────────────────────────────────────────────────
// Shows Temperature + Soil Moisture + Humidity on one chart
export function initOverviewChart(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  const labels = [];
  const datasets = [
    { key: 'temperature',  color: '#f97316', label: 'Temp (°C)',  data: [] },
    { key: 'humidity',     color: '#3b82f6', label: 'Humidity (%)', data: [] },
    { key: 'soilMoisture', color: '#00c785', label: 'Soil (%)',   data: [] },
  ];

  const chart = new Chart(canvas.getContext('2d'), {
    type: 'line',
    data: {
      labels,
      datasets: datasets.map(d => ({
        label: d.label, data: d.data, borderColor: d.color,
        backgroundColor: hexToRgba(d.color, 0.05), fill: false,
        tension: 0.4, borderWidth: 2, pointRadius: 1,
      })),
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: {
          display: true,
          labels: { color: isDark ? '#94a3b8' : '#475569', usePointStyle: true, pointStyleWidth: 10, font: { size: 11 } },
        },
      },
      scales: {
        x: { grid: { color: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' }, ticks: { color: isDark ? '#64748b' : '#94a3b8', maxTicksLimit: 8, font: { size: 10 } } },
        y: { grid: { color: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)' }, ticks: { color: isDark ? '#64748b' : '#94a3b8', font: { size: 10 } } },
      },
      animation: { duration: 400 },
    },
  });
  chartInstances[canvasId] = chart;

  window.addEventListener('sf:sensors', (e) => {
    const s    = e.detail;
    const time = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' });
    labels.push(time);
    datasets.forEach((d, i) => chart.data.datasets[i].data.push(parseFloat(s[d.key] ?? 0)));
    if (labels.length > 30) {
      labels.shift();
      datasets.forEach((_, i) => chart.data.datasets[i].data.shift());
    }
    chart.update('none');
  });

  return chart;
}

// ─── GAUGE CHART ──────────────────────────────────────────────────────────────
export function createGaugeChart(canvasId, color, value = 0) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const pct = Math.min(100, Math.max(0, value));
  const chart = new Chart(canvas.getContext('2d'), {
    type: 'doughnut',
    data: {
      datasets: [{
        data: [pct, 100 - pct],
        backgroundColor: [color, 'rgba(255,255,255,0.05)'],
        borderWidth: 0,
        circumference: 220,
        rotation: -110,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '75%',
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      animation: { duration: 600 },
    },
  });
  chartInstances[canvasId] = chart;
  return chart;
}

export function updateGauge(canvasId, pct) {
  const chart = chartInstances[canvasId];
  if (!chart) return;
  const clamped = Math.min(100, Math.max(0, pct));
  chart.data.datasets[0].data = [clamped, 100 - clamped];
  chart.update('none');
}

// ─── SPARKLINE ────────────────────────────────────────────────────────────────
export function createOrUpdateChart(canvasId, sensorId, labels, data) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const color = SENSOR_COLORS[sensorId] || '#00c785';

  if (chartInstances[canvasId]) {
    chartInstances[canvasId].data.labels   = [...labels];
    chartInstances[canvasId].data.datasets[0].data = [...data];
    chartInstances[canvasId].update('none');
    return chartInstances[canvasId];
  }

  const chart = new Chart(canvas.getContext('2d'), {
    type: 'line',
    data: {
      labels: [...labels],
      datasets: [{ data: [...data], borderColor: color, backgroundColor: hexToRgba(color, 0.1), fill: true, tension: 0.4, borderWidth: 1.5, pointRadius: 0 }],
    },
    options: {
      responsive: true, maintainAspectRatio: false, animation: false,
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: { x: { display: false }, y: { display: false } },
    },
  });
  chartInstances[canvasId] = chart;
  return chart;
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function flattenHistory(raw) {
  const rows = [];
  Object.entries(raw || {}).forEach(([, dayData]) => {
    Object.entries(dayData || {}).forEach(([ts, reading]) => {
      rows.push({ timestamp: parseInt(ts), ...reading });
    });
  });
  return rows.sort((a, b) => a.timestamp - b.timestamp);
}

function hexToRgba(hex, alpha) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

export function destroyChart(canvasId) {
  if (chartInstances[canvasId]) {
    chartInstances[canvasId].destroy();
    delete chartInstances[canvasId];
  }
}
