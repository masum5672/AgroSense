/**
 * dashboard.js
 * AgroSense — Dashboard Controller
 * Updated for exact hardware: DHT11, DS18B20, Soil Moisture, Rain, LDR, Water Level, Pump
 */

import { listenToPath, writeToPath, setPumpStatus } from '../firebase/database.js';
import { DB_PATHS }   from '../firebase/firebaseConfig.js';
import { showToast }  from './notification.js';
import { getSensorStatus, getSensorPercent, formatUptime, animateNumber } from './utils.js';

// ─── EXACT SENSOR CONFIG FOR THIS HARDWARE ───────────────────────────────────
// ✅ IDs match ESP32 /latestReading keys exactly
export const SENSOR_CONFIG = [
  {
    id:       'temperature',
    label:    'Temperature',
    subLabel: 'DHT11 · GPIO4',
    icon:     'fa-thermometer-half',
    unit:     '°C',
    color:    '#f97316',
    colorBg:  'rgba(249,115,22,0.12)',
    decimals: 1,
    min: 0, max: 50,
    thresholds: { low: 10, high: 35 },
  },
  {
    id:       'humidity',
    label:    'Humidity',
    subLabel: 'DHT11 · GPIO4',
    icon:     'fa-droplet',
    unit:     '%',
    color:    '#3b82f6',
    colorBg:  'rgba(59,130,246,0.12)',
    decimals: 1,
    min: 0, max: 100,
    thresholds: { low: 30, high: 80 },
  },
  {
    id:       'soilMoisture',
    label:    'Soil Moisture',
    subLabel: 'Analog · GPIO34',
    icon:     'fa-seedling',
    unit:     '%',
    color:    '#00c785',
    colorBg:  'rgba(0,199,133,0.12)',
    decimals: 0,
    min: 0, max: 100,
    thresholds: { low: 30, high: 90 },
  },
  {
    // ESP32 key: soilTemp (not soilTemperature)
    id:       'soilTemp',
    label:    'Soil Temperature',
    subLabel: 'DS18B20 · GPIO27',
    icon:     'fa-temperature-three-quarters',
    unit:     '°C',
    color:    '#d97706',
    colorBg:  'rgba(217,119,6,0.12)',
    decimals: 1,
    min: 0, max: 50,
    thresholds: { low: 10, high: 35 },
  },
  {
    // ESP32 key: rainLevel (not rain)
    id:       'rainLevel',
    label:    'Rain Sensor',
    subLabel: 'Analog · GPIO35',
    icon:     'fa-cloud-rain',
    unit:     '%',
    color:    '#06b6d4',
    colorBg:  'rgba(6,182,212,0.12)',
    decimals: 0,
    min: 0, max: 100,
    thresholds: { low: 0, high: 50 },
  },
  {
    // ESP32 key: lightLevel (raw ADC, not lux)
    id:       'lightLevel',
    label:    'Light Intensity',
    subLabel: 'LDR · GPIO32',
    icon:     'fa-sun',
    unit:     'ADC',
    color:    '#eab308',
    colorBg:  'rgba(234,179,8,0.12)',
    decimals: 0,
    min: 0, max: 4095,
    thresholds: { low: 500, high: 3500 },
  },
  {
    id:       'waterLevel',
    label:    'Water Level',
    subLabel: 'Analog · GPIO33',
    icon:     'fa-water',
    unit:     '%',
    color:    '#8b5cf6',
    colorBg:  'rgba(139,92,246,0.12)',
    decimals: 0,
    min: 0, max: 100,
    thresholds: { low: 20, high: 95 },
  },
];

// ─── PREVIOUS SENSOR VALUES (for animation) ────────────────────────────────
const prevValues = {};

// ─── INIT DASHBOARD ───────────────────────────────────────────────────────────
export function initDashboard() {
  renderSensorCards();
  listenSensors();
  listenDevice();
  listenPump();
}

// ─── RENDER SENSOR CARDS ─────────────────────────────────────────────────────
function renderSensorCards() {
  const grid = document.getElementById('sensor-grid');
  if (!grid) return;

  grid.innerHTML = SENSOR_CONFIG.map(s => `
    <div class="sensor-card animate-fadeInUp" id="card-${s.id}" style="--card-accent:${s.color};">
      <div class="sensor-card-top">
        <div class="sensor-card-icon" style="background:${s.colorBg};color:${s.color};">
          <i class="fa-solid ${s.icon}"></i>
        </div>
        <div class="sensor-card-meta">
          <div class="sensor-card-label">${s.label}</div>
          <div class="sensor-card-sublabel">${s.subLabel}</div>
        </div>
        <span class="sensor-badge badge-normal" id="badge-${s.id}">Normal</span>
      </div>
      <div class="sensor-card-value-row">
        <span class="sensor-value" id="val-${s.id}">--</span>
        <span class="sensor-unit">${s.unit}</span>
      </div>
      <div class="sf-progress">
        <div class="sf-progress-fill" id="bar-${s.id}" style="background:${s.color};width:0%;"></div>
      </div>
      <div class="sensor-card-footer">
        <span style="font-size:0.7rem;color:var(--text-muted);">0%</span>
        <span style="font-size:0.7rem;color:var(--text-muted);" id="pct-${s.id}">--%</span>
        <span style="font-size:0.7rem;color:var(--text-muted);">100%</span>
      </div>
    </div>
  `).join('');
}

// ─── LISTEN SENSORS ──────────────────────────────────────────────────────────
function listenSensors() {
  listenToPath(DB_PATHS.SENSORS, (sensors) => {
    if (!sensors) return;

    SENSOR_CONFIG.forEach(s => {
      // Skip if sensor key is missing or null — don't show 0 for disconnected sensors
      const raw = sensors[s.id];
      if (raw === undefined || raw === null) return;

      const val    = parseFloat(raw);
      if (isNaN(val)) return;

      const pct    = getSensorPercent(s.id, val);
      const status = getSensorStatus(s.id, val);

      // Animate number
      const valEl = document.getElementById(`val-${s.id}`);
      if (valEl) {
        animateNumber(valEl, parseFloat(prevValues[s.id] ?? val), val, '', s.decimals);
      }
      prevValues[s.id] = val;

      // Progress bar
      const barEl = document.getElementById(`bar-${s.id}`);
      if (barEl) barEl.style.width = `${pct}%`;

      // Percent label
      const pctEl = document.getElementById(`pct-${s.id}`);
      if (pctEl) pctEl.textContent = `${pct.toFixed(0)}%`;

      // Badge
      const badgeEl = document.getElementById(`badge-${s.id}`);
      if (badgeEl) {
        badgeEl.className = `sensor-badge badge-${status.level}`;
        badgeEl.textContent = status.label;
      }
    });

    // Broadcast for charts
    window.dispatchEvent(new CustomEvent('sf:sensors', { detail: sensors }));

    // Last update time
    const lastUpdateEl = document.getElementById('last-update-time');
    if (lastUpdateEl) lastUpdateEl.textContent = new Date().toLocaleTimeString();

    // Auto notifications
    checkNotifications(sensors);
  }, 'dashboard-sensors');
}


// ─── LISTEN DEVICE ─────────────────────────────────────────────────────────
let _lastKnownTs = 0;  // store last known timestamp for periodic re-check

function updateDeviceStatusUI(data, ts) {
  const nowSec  = Math.floor(Date.now() / 1000);
  const diffSec = ts > 1e11 ? Math.abs(Date.now() - ts) / 1000 : Math.abs(nowSec - ts);
  const isOnline = (ts > 0 && diffSec < 35);

  const deviceInfo = {
    online:     isOnline,
    lastUpdate: ts,
    uptime:     data ? (data.uptime || 0) : 0,
    wifiRSSI:   data ? (data.wifiRSSI || 0) : 0,
    ipAddress:  data ? (data.ipAddress || '--') : '--',
  };
  window.dispatchEvent(new CustomEvent('sf:device', { detail: deviceInfo }));

  // Uptime
  const uptimeEl = document.getElementById('device-uptime');
  if (uptimeEl && data) {
    uptimeEl.textContent = data.uptime ? formatUptime(data.uptime) : (isOnline ? 'Active' : '--');
  }

  // WiFi RSSI
  const wifiEl = document.getElementById('wifi-signal-label');
  if (wifiEl && data) wifiEl.textContent = data.wifiRSSI ? `${data.wifiRSSI} dBm` : (isOnline ? 'Connected' : 'Offline');

  // IP Address
  const ipEl = document.getElementById('device-ip');
  if (ipEl && data) ipEl.textContent = data.ipAddress || '--';

  // Online status dots & labels
  document.querySelectorAll('.device-status-dot').forEach(dot => {
    dot.className = `status-dot ${isOnline ? 'online' : 'offline'} device-status-dot`;
  });
  const labelEl = document.getElementById('topbar-device-label');
  if (labelEl) labelEl.textContent = isOnline ? 'ESP32 Online' : 'ESP32 Offline';
  const sidebarValEl = document.getElementById('sidebar-device-value');
  if (sidebarValEl) sidebarValEl.textContent = isOnline ? 'Online' : 'Offline';
}

function listenDevice() {
  // ── Firebase listener: updates UI when new data arrives ──
  listenToPath(DB_PATHS.DEVICE, (data) => {
    if (!data) return;
    const ts = typeof data.lastUpdate === 'number' ? data.lastUpdate : (data.timestamp || 0);
    _lastKnownTs = ts;  // store for periodic re-check
    updateDeviceStatusUI(data, ts);
  }, 'dashboard-device');

  // ── Periodic re-check every 5s: catches offline when Firebase stops sending events ──
  setInterval(() => {
    if (_lastKnownTs > 0) {
      updateDeviceStatusUI(null, _lastKnownTs);
    }
  }, 5000);
}


// ─── LISTEN PUMP ─────────────────────────────────────────────────────────────
// ESP32 reads /config/pumpCommand for pump state.
// Web reads /latestReading/pumpState to show current pump status.
function listenPump() {
  listenToPath('latestReading', (data) => {
    if (!data) return;
    const isRunning = !!data.pumpState;
    const pump = { status: isRunning, mode: 'manual', runtime: 0 };
    window.dispatchEvent(new CustomEvent('sf:pump', { detail: pump }));

    // Pump status indicator
    const indicator  = document.getElementById('pump-indicator');
    const indLabel   = document.getElementById('pump-ind-label');
    const statusText = document.getElementById('pump-status-text');

    if (indicator) indicator.className = `pump-big-indicator ${isRunning ? 'running' : 'stopped'}`;
    if (indLabel)  indLabel.textContent  = isRunning ? 'RUNNING' : 'STOPPED';
    if (statusText) {
      statusText.textContent = isRunning ? 'Pump is Running' : 'Pump is Stopped';
      statusText.style.color = isRunning ? 'var(--color-success)' : 'var(--color-danger)';
    }

    // ON/OFF buttons
    const btnOn  = document.getElementById('btn-pump-on');
    const btnOff = document.getElementById('btn-pump-off');
    if (btnOn)  btnOn.disabled  = isRunning;
    if (btnOff) btnOff.disabled = !isRunning;

    // Status stat box
    const statEl = document.getElementById('pump-status-stat');
    if (statEl) {
      statEl.textContent = isRunning ? 'ON' : 'OFF';
      statEl.style.color = isRunning ? 'var(--color-success)' : 'var(--color-danger)';
    }
  }, 'dashboard-pump');
}

// ─── AUTO NOTIFICATIONS ───────────────────────────────────────────────────────
let lastNotifState = {};

function checkNotifications(sensors) {
  const soilThreshold = parseInt(localStorage.getItem('sf_soil_threshold') || '30');

  // Soil moisture below threshold
  if (sensors.soilMoisture < soilThreshold && lastNotifState.soilLow !== true) {
    showToast('⚠️ Low Soil Moisture', `Soil moisture is ${sensors.soilMoisture}% (threshold: ${soilThreshold}%)`, 'warning');
    lastNotifState.soilLow = true;
  } else if (sensors.soilMoisture >= soilThreshold) {
    lastNotifState.soilLow = false;
  }

  // Rain detected (ESP32 key: rainLevel)
  if (sensors.rainLevel > 50 && lastNotifState.rainDetected !== true) {
    showToast('🌧️ Rain Detected', `Rain sensor reads ${sensors.rainLevel}%`, 'info');
    lastNotifState.rainDetected = true;
  } else if ((sensors.rainLevel || 0) <= 50) {
    lastNotifState.rainDetected = false;
  }

  // Water level low
  if (sensors.waterLevel < 20 && lastNotifState.waterLow !== true) {
    showToast('🪣 Water Level Low', `Water tank at ${sensors.waterLevel}%`, 'danger');
    lastNotifState.waterLow = true;
  } else if (sensors.waterLevel >= 20) {
    lastNotifState.waterLow = false;
  }
}
