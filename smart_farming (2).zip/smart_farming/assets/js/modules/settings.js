/**
 * settings.js
 * AgroSense — Settings Module
 * Updated for exact hardware thresholds: soilThreshold, rainThreshold, lightThreshold
 */

import { readOnce, saveSettings }  from '../firebase/database.js';
import { DB_PATHS }                from '../firebase/firebaseConfig.js';
import { showToast }               from './notification.js';
import { applyTheme, toggleTheme } from './utils.js';
import { getCurrentUser, getUserRole } from '../firebase/auth.js';

export async function initSettings() {
  const user = getCurrentUser();
  const role = user ? await getUserRole(user.uid) : 'visitor';

  // Load saved settings from Firebase
  const saved = await readOnce(DB_PATHS.SETTINGS) || {};

  const soil  = saved.soilThreshold   ?? 30;
  const rain  = saved.rainThreshold   ?? 50;
  const light = saved.lightThreshold  ?? 200;
  const intv  = saved.updateInterval  ?? 2;

  // Set slider values
  setSlider('setting-soil-threshold',    soil,  'setting-soil-threshold-display',    `${soil}%`);
  setSlider('setting-rain-threshold',    rain,  'setting-rain-threshold-display',    `${rain}%`);
  setSlider('setting-light-threshold',   light, 'setting-light-threshold-display',   `${light} lux`);
  setSlider('setting-update-interval',   intv,  'setting-update-interval-display',   `${intv}s`);

  // Save to localStorage for dashboard notifications
  localStorage.setItem('sf_soil_threshold', soil);

  // Slider live update labels
  bindSlider('setting-soil-threshold',   'setting-soil-threshold-display',   v => `${v}%`);
  bindSlider('setting-rain-threshold',   'setting-rain-threshold-display',   v => `${v}%`);
  bindSlider('setting-light-threshold',  'setting-light-threshold-display',  v => `${v} lux`);
  bindSlider('setting-update-interval',  'setting-update-interval-display',  v => `${v}s`);

  // Theme init
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
  const themeToggle  = document.getElementById('theme-toggle');
  if (themeToggle) themeToggle.checked = currentTheme === 'light';
  updateThemePreviews(currentTheme);

  themeToggle?.addEventListener('change', () => {
    const theme = themeToggle.checked ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('sf_theme', theme);
    updateThemePreviews(theme);
    const labelEl = document.getElementById('theme-label');
    if (labelEl) labelEl.textContent = theme === 'dark' ? 'Dark Mode' : 'Light Mode';
  });

  // Save Button
  const btnSave = document.getElementById('btn-save-settings');
  if (btnSave && role === 'visitor') {
    btnSave.disabled = true;
    btnSave.innerHTML = '<i class="fa-solid fa-lock"></i> Save Settings (View Only)';
  }
  
  btnSave?.addEventListener('click', async () => {
    if (role === 'visitor') return showToast('Access Denied', 'Visitors cannot change settings.', 'warning');
    const soilVal  = parseInt(document.getElementById('setting-soil-threshold')?.value  || 30);
    const rainVal  = parseInt(document.getElementById('setting-rain-threshold')?.value  || 50);
    const lightVal = parseInt(document.getElementById('setting-light-threshold')?.value || 200);
    const intvVal  = parseInt(document.getElementById('setting-update-interval')?.value || 2);

    try {
      await saveSettings({
        soilThreshold:  soilVal,
        rainThreshold:  rainVal,
        lightThreshold: lightVal,
        updateInterval: intvVal,
      });
      localStorage.setItem('sf_soil_threshold', soilVal);
      showToast('Settings Saved', 'Thresholds updated in Firebase.', 'success');
    } catch (e) {
      showToast('Error', e.message, 'danger');
    }
  });

  // Reset Button
  const btnReset = document.getElementById('btn-reset-settings');
  if (btnReset && role === 'visitor') btnReset.disabled = true;

  btnReset?.addEventListener('click', () => {
    if (role === 'visitor') return showToast('Access Denied', 'Visitors cannot reset settings.', 'warning');
    setSlider('setting-soil-threshold',   30,  'setting-soil-threshold-display',   '30%');
    setSlider('setting-rain-threshold',   50,  'setting-rain-threshold-display',   '50%');
    setSlider('setting-light-threshold',  200, 'setting-light-threshold-display',  '200 lux');
    setSlider('setting-update-interval',  2,   'setting-update-interval-display',  '2s');
    showToast('Reset', 'Settings reset to defaults.', 'info');
  });
}

function setSlider(sliderId, value, displayId, displayText) {
  const slider  = document.getElementById(sliderId);
  const display = document.getElementById(displayId);
  if (slider)  slider.value   = value;
  if (display) display.textContent = displayText;
}

function bindSlider(sliderId, displayId, format) {
  const slider  = document.getElementById(sliderId);
  const display = document.getElementById(displayId);
  slider?.addEventListener('input', () => {
    if (display) display.textContent = format(slider.value);
  });
}

function updateThemePreviews(theme) {
  const dark  = document.getElementById('preview-dark');
  const light = document.getElementById('preview-light');
  if (dark)  dark.style.borderColor  = theme === 'dark'  ? 'var(--brand-primary)' : 'var(--border-color)';
  if (light) light.style.borderColor = theme === 'light' ? 'var(--brand-primary)' : 'var(--border-color)';
}
