/**
 * pump.js
 * AgroSense — Pump Control Module
 * Updated for exact hardware: Relay GPIO26, paths SmartFarming/Pump/status, mode, runtime
 */

import { listenToPath, setPumpStatus, setPumpMode, writeToPath } from '../firebase/database.js';
import { DB_PATHS }    from '../firebase/firebaseConfig.js';
import { showToast }   from './notification.js';
import { formatUptime } from './utils.js';
import { getCurrentUser, getUserRole } from '../firebase/auth.js';

let pumpTimerInterval = null;

export async function initPumpControl() {
  const user = getCurrentUser();
  const role = user ? await getUserRole(user.uid) : 'visitor';

  listenPump(role);
  bindButtons(role);
  bindModeToggle(role);
  bindSchedule(role);
}

// ─── LISTEN PUMP STATE ────────────────────────────────────────────────────────────
function listenPump(role) {
  // Listen to SmartFarming/Pump for mode, status, and runtime
  listenToPath(DB_PATHS.PUMP, (pumpData) => {
    if (!pumpData) return;
    const isRunning = !!pumpData.status;
    const isAuto    = pumpData.mode === 'auto';

    // Update Indicators
    const indicator  = document.getElementById('pump-indicator');
    const indLabel   = document.getElementById('pump-ind-label');
    const statusText = document.getElementById('pump-status-text');
    if (indicator) indicator.className = `pump-big-indicator ${isRunning ? 'running' : 'stopped'}`;
    if (indLabel)  indLabel.textContent  = isRunning ? 'RUNNING' : 'STOPPED';
    if (statusText) {
      statusText.textContent = isRunning ? 'Pump is Running' : 'Pump is Stopped';
      statusText.style.color = isRunning ? 'var(--color-success)' : 'var(--color-danger)';
    }
    const statEl = document.getElementById('pump-status-stat');
    if (statEl) {
      statEl.textContent = isRunning ? 'ON' : 'OFF';
      statEl.style.color = isRunning ? 'var(--color-success)' : 'var(--color-danger)';
    }
    window.dispatchEvent(new CustomEvent('sf:pump', { detail: { status: isRunning } }));

    // Buttons (disabled in auto or if visitor)
    const btnOn  = document.getElementById('btn-pump-on');
    const btnOff = document.getElementById('btn-pump-off');
    if (btnOn)  btnOn.disabled  = isRunning || isAuto || role === 'visitor';
    if (btnOff) btnOff.disabled = !isRunning || isAuto || role === 'visitor';

    // Manual controls visibility
    const manualControls = document.getElementById('manual-controls');
    const autoControls   = document.getElementById('auto-controls');
    if (manualControls) manualControls.style.display = isAuto ? 'none' : '';
    if (autoControls)   autoControls.style.display   = isAuto ? ''     : 'none';

    // Mode toggle
    const modeToggle = document.getElementById('pump-mode-toggle');
    if (modeToggle) {
      modeToggle.checked = isAuto;
      if (role === 'visitor') modeToggle.disabled = true;
    }

    // Labels
    const modeLbl  = document.getElementById('pump-mode-label');
    const modeLbl2 = document.getElementById('pump-mode-label-2');
    const modeDesc = document.getElementById('pump-mode-desc');
    const modeStat = document.getElementById('pump-mode-stat');
    if (modeLbl)  modeLbl.textContent  = isAuto ? 'Auto'      : 'Manual';
    if (modeLbl2) modeLbl2.textContent = isAuto ? 'Auto Mode' : 'Manual Mode';
    if (modeDesc) modeDesc.textContent = isAuto
      ? 'Pump activates based on soil threshold'
      : 'You control the pump manually';
    if (modeStat) modeStat.textContent = isAuto ? 'Auto' : 'Manual';

    // Mode bar
    const modeBar = document.getElementById('pump-mode-bar');
    if (modeBar) modeBar.style.width = isAuto ? '100%' : '0%';

    // Mode badge
    const badge = document.getElementById('mode-badge');
    if (badge) {
      badge.style.background = isAuto ? 'rgba(0,199,133,0.12)' : 'rgba(59,130,246,0.12)';
      badge.style.color      = isAuto ? 'var(--brand-primary)'  : '#3b82f6';
      badge.innerHTML = isAuto
        ? '<i class="fa-solid fa-robot"></i> Auto Mode'
        : '<i class="fa-solid fa-hand-pointer"></i> Manual Mode';
      if (role === 'visitor') {
        badge.innerHTML += ' <span style="color:var(--color-danger); font-size:0.8em; margin-left:8px;">(View Only)</span>';
      }
    }
  }, 'pump-livestate');

  // Listen to SmartFarming/Config for moisture threshold
  listenToPath(DB_PATHS.SETTINGS, (cfg) => {
    if (!cfg) return;
    const thrEl = document.getElementById('auto-threshold-display');
    if (thrEl) thrEl.textContent = `${cfg.moistureThreshold ?? 30}%`;
  }, 'pump-page-config');
}

// ─── BIND BUTTONS ───────────────────────────────────────────────────────────────────
function bindButtons(role) {
  // ON button → writes true to SmartFarming/Pump/status (ESP32 reads this)
  document.getElementById('btn-pump-on')?.addEventListener('click', async () => {
    if (role === 'visitor') return showToast('Access Denied', 'Visitors cannot control the pump.', 'warning');
    try {
      await writeToPath(`${DB_PATHS.PUMP}/status`, true);
      showToast('Pump ON', 'Command sent. Relay GPIO26 will activate.', 'success');
    } catch (e) {
      showToast('Error', e.message, 'danger');
    }
  });

  // OFF button → writes false to SmartFarming/Pump/status
  document.getElementById('btn-pump-off')?.addEventListener('click', async () => {
    if (role === 'visitor') return showToast('Access Denied', 'Visitors cannot control the pump.', 'warning');
    try {
      await writeToPath(`${DB_PATHS.PUMP}/status`, false);
      showToast('Pump OFF', 'Command sent. Relay GPIO26 will deactivate.', 'info');
    } catch (e) {
      showToast('Error', e.message, 'danger');
    }
  });

  // Quick Run buttons (timed irrigation)
  document.querySelectorAll('[data-pump-duration]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (role === 'visitor') return showToast('Access Denied', 'Visitors cannot control the pump.', 'warning');
      const minutes = parseInt(btn.dataset.pumpDuration);
      try {
        await writeToPath(`${DB_PATHS.PUMP}/status`, true);
        showToast('Quick Run', `Pump will run for ${minutes} minutes.`, 'success');
        setTimeout(async () => {
          await writeToPath(`${DB_PATHS.PUMP}/status`, false);
          showToast('Quick Run Done', `${minutes} min irrigation complete.`, 'info');
        }, minutes * 60 * 1000);
      } catch (e) {
        showToast('Error', e.message, 'danger');
      }
    });
  });
}

// ─── MODE TOGGLE ───────────────────────────────────────────────────────────────────
// Toggle checked = AUTO → mode='auto', unchecked = MANUAL → mode='manual'
function bindModeToggle(role) {
  document.getElementById('pump-mode-toggle')?.addEventListener('change', async (e) => {
    if (role === 'visitor') {
      e.target.checked = !e.target.checked; // revert
      return showToast('Access Denied', 'Visitors cannot change pump mode.', 'warning');
    }
    const isAuto = e.target.checked;
    try {
      // ESP32 reads mode: 'auto' or 'manual'
      await writeToPath(DB_PATHS.PUMP_MODE, isAuto ? 'auto' : 'manual');
      showToast('Mode Changed', `Switched to ${isAuto ? 'AUTO' : 'MANUAL'} mode.`, 'info');
    } catch (err) {
      showToast('Error', err.message, 'danger');
    }
  });
}

// ─── SCHEDULE ─────────────────────────────────────────────────────────────────
function bindSchedule(role) {
  const btn = document.getElementById('btn-save-schedule');
  if (btn && role === 'visitor') btn.disabled = true;

  btn?.addEventListener('click', async () => {
    if (role === 'visitor') return showToast('Access Denied', 'Visitors cannot set schedules.', 'warning');
    const enabled   = document.getElementById('schedule-enabled')?.checked || false;
    const startTime = document.getElementById('schedule-start')?.value    || '06:00';
    const duration  = parseInt(document.getElementById('schedule-duration')?.value || 30);
    try {
      await writeToPath('SmartFarming/Pump/schedule', { enabled, startTime, duration });
      showToast('Schedule Saved', `Schedule set for ${startTime}, ${duration} min.`, 'success');
    } catch (e) {
      showToast('Error', e.message, 'danger');
    }
  });
}
