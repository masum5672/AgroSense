/**
 * firebaseConfig.js
 * AgroSense — Firebase SDK Initialization
 * Paths synced with ESP32 firmware (latestReading / config / history / alerts)
 */

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import { getDatabase } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
import { getAnalytics, isSupported } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-analytics.js';

const firebaseConfig = {
  apiKey: "AIzaSyAgMzY-3nDHQ2BJkPDkY7dUiGSDV6wefag",
  authDomain: "smart-farming-3d1f2.firebaseapp.com",

  databaseURL: "https://smart-farming-3d1f2-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "smart-farming-3d1f2",
  storageBucket: "smart-farming-3d1f2.firebasestorage.app",
  messagingSenderId: "243776816862",
  appId: "1:243776816862:web:9dda8fa2f345cd0d1fe44f",
  measurementId: "G-TPNVRTN303"
};

let app = null, database = null, auth = null;
let isDemoFallback = false;

try {
  app = initializeApp(firebaseConfig);
} catch (err) {
  console.warn('[Firebase] initializeApp error, enabling demo mode:', err);
  isDemoFallback = true;
}

if (app) {
  try { database = getDatabase(app); } catch (e) { console.warn('[Firebase] DB error:', e); }
  try { auth = getAuth(app); } catch (e) { console.warn('[Firebase] Auth error:', e); }
  try { isSupported().then(ok => { if (ok) getAnalytics(app); }).catch(() => { }); } catch (e) { }
}

export const DEMO_MODE = isDemoFallback || !firebaseConfig.apiKey || firebaseConfig.apiKey === 'YOUR_API_KEY';

// ─── DATABASE PATHS — SYNCED WITH ESP32 FIRMWARE ─────────────────────────────
export const DB_PATHS = {
  // ── Sensor Live Data ──────────────────────────────
  SENSORS: 'SmartFarming/Sensors',
  
  // ── Pump Control (Web ↔ ESP32) ───────────────────────────
  PUMP: 'SmartFarming/Pump',
  PUMP_MODE: 'SmartFarming/Pump/mode',

  // ── Config / Settings ─────────────────────────
  SETTINGS: 'SmartFarming/Config',

  // ── History ──────────────────────────────────────
  HISTORY: 'SmartFarming/History',

  // ── Alerts ────────────────────────────────────
  ALERTS: 'SmartFarming/Alerts',

  // ── Device / Online status ──────────────────────────
  DEVICE: 'SmartFarming/Device',
  
  // Legacy aliases (kept for compatibility)
  NOTIFICATIONS: 'alerts',
  USERS: 'users',
};

export { app, database, auth };
export default app;
