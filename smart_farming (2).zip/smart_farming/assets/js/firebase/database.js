/**
 * database.js
 * AgroSense — Firebase Realtime Database Module
 * Updated for exact hardware sensor keys matching ESP32 firmware
 */

import {
  ref, get, set, update, onValue, off,
  query, limitToLast, orderByKey, startAt, endAt,
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js';

import { database, DB_PATHS, DEMO_MODE } from './firebaseConfig.js';

const activeListeners = new Map();

// ─── READ ─────────────────────────────────────────────────────────────────────
export async function readOnce(path) {
  if (DEMO_MODE || !database) return generateDemoData(path);
  try {
    const snap = await get(ref(database, path));
    return snap.exists() ? snap.val() : null;
  } catch (e) { return generateDemoData(path); }
}

export function listenToPath(path, callback, listenerId = null) {
  if (DEMO_MODE || !database) return simulateDemoListener(path, callback);
  const dbRef = ref(database, path);
  const unsub = onValue(
    dbRef,
    snap => callback(snap.exists() ? snap.val() : null, null),
    err  => callback(null, err)
  );
  activeListeners.set(listenerId || path, { dbRef, unsub });
  return () => removeListener(listenerId || path);
}

export function removeListener(id) {
  const entry = activeListeners.get(id);
  if (entry) { off(entry.dbRef); activeListeners.delete(id); }
}

export function removeAllListeners() {
  activeListeners.forEach(({ dbRef }) => off(dbRef));
  activeListeners.clear();
}

// ─── WRITE ────────────────────────────────────────────────────────────────────
export async function writeToPath(path, value) {
  if (DEMO_MODE || !database) { console.log('[DEMO] Write:', path, value); return; }
  await set(ref(database, path), value);
}

export async function updatePath(path, updates) {
  if (DEMO_MODE || !database) { console.log('[DEMO] Update:', path, updates); return; }
  await update(ref(database, path), updates);
}

// ─── PUMP CONTROL ─────────────────────────────────────────────────────────────
export async function setPumpStatus(status) {
  await updatePath(DB_PATHS.PUMP, { status, lastChanged: Date.now() });
}

export async function setPumpMode(mode) {
  await writeToPath(DB_PATHS.PUMP_MODE, mode);
}

// ─── SETTINGS ─────────────────────────────────────────────────────────────────
export async function saveSettings(settings) {
  await updatePath(DB_PATHS.SETTINGS, settings);
}

// ─── HISTORY ─────────────────────────────────────────────────────────────────
export async function getHistory(startDate, endDate = null) {
  if (DEMO_MODE || !database) return generateDemoHistory(startDate, endDate);
  try {
    const histRef = ref(database, DB_PATHS.HISTORY);
    const q = endDate
      ? query(histRef, orderByKey(), startAt(startDate), endAt(endDate))
      : query(histRef, orderByKey(), startAt(startDate));
    const snap = await get(q);
    return snap.exists() ? snap.val() : {};
  } catch (e) { return generateDemoHistory(startDate, endDate); }
}

export async function getLatestHistory(n = 60) {
  if (DEMO_MODE || !database) return generateDemoChartData(n);
  try {
    const snap = await get(query(ref(database, DB_PATHS.HISTORY), limitToLast(n)));
    return snap.exists() ? snap.val() : {};
  } catch (e) { return generateDemoChartData(n); }
}

// ─── DEMO MODE HELPERS ────────────────────────────────────────────────────────
let demoIntervals = [];

function generateDemoData(path) {
  const now = Date.now();
  const map = {
    [DB_PATHS.DEVICE]: {
      online: true, lastUpdate: now, uptime: 7200,
      wifiRSSI: -58, ipAddress: '192.168.1.105'
    },
    [DB_PATHS.SENSORS]: {
      temperature: 27.4, humidity: 68,
      soilMoisture: 42, soilTemperature: 24.1,
      rain: 0, light: 650, waterLevel: 78
    },
    [DB_PATHS.PUMP]: {
      status: false, mode: 'manual', runtime: 0
    },
    [DB_PATHS.SETTINGS]: {
      soilThreshold: 30, rainThreshold: 50,
      lightThreshold: 200, updateInterval: 2
    },
  };
  return map[path] || null;
}

function simulateDemoListener(path, callback) {
  callback(generateDemoData(path), null);
  const interval = setInterval(() => {
    if (path === DB_PATHS.SENSORS || path === DB_PATHS.DEVICE) {
      callback(generateLiveDemo(path), null);
    }
  }, 3000);
  demoIntervals.push(interval);
  return () => clearInterval(interval);
}

function generateLiveDemo(path) {
  if (path === DB_PATHS.SENSORS) {
    return {
      temperature:     +(24 + Math.random() * 10).toFixed(1),
      humidity:        +(55 + Math.random() * 30).toFixed(1),
      soilMoisture:    +(20 + Math.random() * 60).toFixed(0),
      soilTemperature: +(20 + Math.random() * 10).toFixed(1),
      rain:            +(Math.random() * 100).toFixed(0),
      light:           +(200 + Math.random() * 800).toFixed(0),
      waterLevel:      +(40 + Math.random() * 60).toFixed(0),
    };
  }
  if (path === DB_PATHS.DEVICE) {
    return {
      online: true, lastUpdate: Date.now(),
      uptime: 7200 + Math.floor(Math.random() * 100),
      wifiRSSI: -55 - Math.floor(Math.random() * 20),
      ipAddress: '192.168.1.105'
    };
  }
  return generateDemoData(path);
}

function generateDemoHistory(startDate, endDate) {
  const result = {};
  const start  = new Date(startDate);
  const end    = endDate ? new Date(endDate) : new Date();
  const day    = new Date(start);
  while (day <= end) {
    const dateKey = day.toISOString().split('T')[0];
    result[dateKey] = {};
    for (let h = 0; h < 24; h++) {
      const ts = new Date(day).setHours(h, 0, 0, 0);
      result[dateKey][ts] = {
        temperature:     +(22 + Math.sin(h/3)*5 + Math.random()*2).toFixed(1),
        humidity:        +(60 + Math.cos(h/4)*15 + Math.random()*5).toFixed(1),
        soilMoisture:    +(30 + Math.random()*40).toFixed(0),
        soilTemperature: +(20 + Math.sin(h/6)*4 + Math.random()).toFixed(1),
        rain:            +(Math.random()>0.8 ? Math.random()*100 : 0).toFixed(0),
        light:           h>=6&&h<=20 ? +(300 + Math.random()*700).toFixed(0) : 0,
        waterLevel:      +(50 + Math.random()*40).toFixed(0),
      };
    }
    day.setDate(day.getDate() + 1);
  }
  return result;
}

function generateDemoChartData(n) {
  const result = {}, now = Date.now();
  for (let i = n; i > 0; i--) {
    const ts = now - i * 2000;
    result[ts] = {
      temperature:     +(22 + Math.sin(i/10)*5 + Math.random()).toFixed(1),
      humidity:        +(60 + Math.cos(i/8)*15 + Math.random()*2).toFixed(1),
      soilMoisture:    +(30 + Math.random()*40).toFixed(0),
      soilTemperature: +(20 + Math.random()*8).toFixed(1),
      rain:            +(Math.random()>0.9 ? Math.random()*100 : 0).toFixed(0),
      light:           +(400 + Math.random()*500).toFixed(0),
      waterLevel:      +(50 + Math.random()*40).toFixed(0),
    };
  }
  return result;
}

export function cleanupDemo() {
  demoIntervals.forEach(clearInterval);
  demoIntervals = [];
}

export { ref, database };
