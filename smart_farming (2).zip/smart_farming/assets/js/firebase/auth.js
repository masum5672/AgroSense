/**
 * auth.js
 * AgroSense — Firebase Authentication Module
 * 
 * Handles:
 *  - Email/Password Sign In
 *  - Registration
 *  - Forgot Password
 *  - Remember Me (via localStorage)
 *  - Auth State Observer
 *  - Sign Out
 */

import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  updateProfile,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';

import { auth, DEMO_MODE } from './firebaseConfig.js';
import { showToast }        from '../modules/notification.js';

// ─── AUTH STATE ───────────────────────────────────────────────────────────────

/**
 * Returns the currently signed-in user or null.
 */
export function getCurrentUser() {
  return auth.currentUser;
}

/**
 * Observe auth state changes.
 * @param {function} callback - called with (user | null)
 * @returns {function} unsubscribe function
 */
export function onAuthChange(callback) {
  return onAuthStateChanged(auth, callback);
}

/**
 * Guard: redirect to login if unauthenticated.
 * Call this at the top of every protected page.
 * @param {string} [loginUrl='/login.html']
 */
export function requireAuth(loginUrl = '/login.html') {
  if (DEMO_MODE) return; // Skip in demo mode
  return new Promise(resolve => {
    const unsub = onAuthStateChanged(auth, user => {
      unsub();
      if (!user) {
        window.location.href = loginUrl;
      } else {
        resolve(user);
      }
    });
  });
}

// ─── SIGN IN ──────────────────────────────────────────────────────────────────

/**
 * Sign in with email and password.
 * @param {string} email
 * @param {string} password
 * @param {boolean} rememberMe - whether to persist session across tabs
 * @returns {Promise<UserCredential>}
 */
export async function signIn(email, password, rememberMe = false) {
  try {
    // Set persistence based on remember-me checkbox
    const persistenceType = rememberMe
      ? browserLocalPersistence
      : browserSessionPersistence;

    await setPersistence(auth, persistenceType);
    const userCredential = await signInWithEmailAndPassword(auth, email, password);

    // Store remember-me preference
    if (rememberMe) {
      localStorage.setItem('sf_remember', '1');
    } else {
      localStorage.removeItem('sf_remember');
    }

    return userCredential;
  } catch (error) {
    throw interpretAuthError(error);
  }
}

// ─── REGISTER ─────────────────────────────────────────────────────────────────

/**
 * Create a new user account and set role to visitor.
 * @param {string} email
 * @param {string} password
 * @param {string} displayName
 * @returns {Promise<UserCredential>}
 */
export async function register(email, password, displayName) {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    // Update the display name
    if (displayName) {
      await updateProfile(userCredential.user, { displayName });
    }
    
    // Set default role to visitor
    try {
      const { ref, set } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js');
      const { database } = await import('./firebaseConfig.js');
      if (database) {
        await set(ref(database, `users/${userCredential.user.uid}/role`), 'visitor');
      }
    } catch (dbErr) {
      console.warn('Failed to set visitor role:', dbErr);
    }
    
    return userCredential;
  } catch (error) {
    throw interpretAuthError(error);
  }
}

// ─── USER ROLES ───────────────────────────────────────────────────────────────

/**
 * Fetch the role for a given user UID.
 * Defaults to 'visitor' if not found or on error.
 * @param {string} uid
 * @returns {Promise<string>} 'admin' or 'visitor'
 */
export async function getUserRole(uid) {
  try {
    const { ref, get } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js');
    const { database } = await import('./firebaseConfig.js');
    if (!database) return 'visitor';
    
    const snap = await get(ref(database, `users/${uid}/role`));
    if (snap.exists()) {
      return snap.val();
    }
    // If no role is found (e.g. legacy account not set up yet), default to visitor for safety
    return 'visitor';
  } catch (error) {
    console.warn('Error fetching user role:', error);
    return 'visitor';
  }
}

// ─── FORGOT PASSWORD ──────────────────────────────────────────────────────────

/**
 * Send a password reset email.
 * @param {string} email
 * @returns {Promise<void>}
 */
export async function forgotPassword(email) {
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (error) {
    throw interpretAuthError(error);
  }
}

// ─── SIGN OUT ─────────────────────────────────────────────────────────────────

/**
 * Sign out the current user and redirect to login page.
 */
export async function signOutUser() {
  try {
    await signOut(auth);
    localStorage.removeItem('sf_remember');
    window.location.href = '/login.html';
  } catch (error) {
    showToast('Sign Out Error', error.message, 'danger');
  }
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

/**
 * Convert Firebase auth error codes to human-readable messages.
 * @param {FirebaseError} error
 * @returns {Error}
 */
function interpretAuthError(error) {
  const messages = {
    'auth/user-not-found':       'No account found with this email address.',
    'auth/wrong-password':       'Incorrect password. Please try again.',
    'auth/invalid-email':        'Please enter a valid email address.',
    'auth/user-disabled':        'This account has been disabled. Contact support.',
    'auth/too-many-requests':    'Too many failed attempts. Please try again later.',
    'auth/email-already-in-use': 'An account with this email already exists.',
    'auth/weak-password':        'Password must be at least 6 characters.',
    'auth/network-request-failed': 'Network error. Check your internet connection.',
    'auth/invalid-credential':   'Invalid credentials. Please check your email and password.',
  };
  const msg = messages[error.code] || error.message;
  return new Error(msg);
}

/**
 * Get user initials for avatar display.
 * @param {User} user
 * @returns {string}
 */
export function getUserInitials(user) {
  if (!user) return '?';
  if (user.displayName) {
    return user.displayName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  }
  return user.email ? user.email[0].toUpperCase() : '?';
}

export { auth };
