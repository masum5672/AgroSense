import os
import json
import urllib.parse
import shutil

history_dir = 'C:/Users/emamm/AppData/Roaming/Code/User/History'
target_dir = 'd:/smart_farming'

# Store the latest valid backup for each file
backups = {}

for folder in os.listdir(history_dir):
    folder_path = os.path.join(history_dir, folder)
    if not os.path.isdir(folder_path):
        continue
    
    entries_file = os.path.join(folder_path, 'entries.json')
    if not os.path.exists(entries_file):
        continue
        
    try:
        with open(entries_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        resource_url = data.get('resource', '')
        if not resource_url.startswith('file:///d%3A/smart_farming') and not resource_url.startswith('file:///d:/smart_farming'):
            continue
            
        # Parse the original file path
        # file:///d%3A/smart_farming/...
        parsed_url = urllib.parse.unquote(resource_url)
        if parsed_url.startswith('file:///'):
            parsed_url = parsed_url[8:] # remove file:///
        
        # Replace forward slashes with backslashes
        original_path = parsed_url.replace('/', '\\')
        
        # Get the latest entry
        entries = data.get('entries', [])
        for entry in reversed(entries):
            file_id = entry.get('id')
            backup_path = os.path.join(folder_path, file_id)
            if os.path.exists(backup_path) and os.path.getsize(backup_path) > 0:
                # We found a valid non-empty backup!
                timestamp = entry.get('timestamp', 0)
                if original_path not in backups or backups[original_path]['timestamp'] < timestamp:
                    backups[original_path] = {
                        'backup_path': backup_path,
                        'timestamp': timestamp
                    }
                break # Found the latest valid for this folder
                
    except Exception as e:
        print(f"Error processing {entries_file}: {e}")

# Now restore the files
for original_path, info in backups.items():
    if original_path.endswith('.html'):
        print(f"Restoring {original_path} from {info['backup_path']}")
        shutil.copy2(info['backup_path'], original_path)

print(f"Restored {len(backups)} files.")
