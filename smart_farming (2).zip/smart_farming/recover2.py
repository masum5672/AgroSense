import os
import json
import urllib.parse
import shutil

history_dir = 'C:/Users/emamm/AppData/Roaming/Code/User/History'
target_dir = 'd:/smart_farming'

backups = {}

if os.path.exists(history_dir):
    for folder in os.listdir(history_dir):
        folder_path = os.path.join(history_dir, folder)
        if not os.path.isdir(folder_path):
            continue
        
        entries_file = os.path.join(folder_path, 'entries.json')
        if not os.path.exists(entries_file):
            continue
            
        try:
            with open(entries_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            resource_url = data.get('resource', '').lower()
            if not ('smart_farming' in resource_url):
                continue
                
            # Print to see if we find anything!
            print(f"Found related resource: {resource_url}")
            
            # Parse the original file path
            parsed_url = urllib.parse.unquote(resource_url)
            if parsed_url.startswith('file:///'):
                parsed_url = parsed_url[8:] # remove file:///
            
            original_path = parsed_url.replace('/', '\\')
            
            entries = data.get('entries', [])
            for entry in reversed(entries):
                file_id = entry.get('id')
                backup_path = os.path.join(folder_path, file_id)
                if os.path.exists(backup_path) and os.path.getsize(backup_path) > 0:
                    timestamp = entry.get('timestamp', 0)
                    if original_path not in backups or backups[original_path]['timestamp'] < timestamp:
                        backups[original_path] = {
                            'backup_path': backup_path,
                            'timestamp': timestamp
                        }
                    break
                    
        except Exception as e:
            pass

print(f"Found {len(backups)} backups to restore.")
for original_path, info in backups.items():
    if original_path.endswith('.html'):
        print(f"Restoring {original_path} from {info['backup_path']}")
        try:
            # original_path might be lowercase drive letter, we just write to it
            shutil.copy2(info['backup_path'], original_path)
        except Exception as e:
            print(e)
