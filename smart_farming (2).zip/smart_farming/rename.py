import os
import re

directories = [
    'd:\\smart_farming',
]

extensions = ['.html', '.js', '.json', '.ino']

replacements = [
    (re.compile(r'Smart Farmer', re.IGNORECASE), 'AgroSense User'),
    (re.compile(r'Smart Farming( |)System', re.IGNORECASE), 'AgroSense System'),
    (re.compile(r'Smart Farming( |)IoT Dashboard', re.IGNORECASE), 'AgroSense IoT Dashboard'),
    (re.compile(r'Smart Farming', re.IGNORECASE), 'AgroSense'),
    (re.compile(r'Smart Farm Report', re.IGNORECASE), 'AgroSense Report'),
    (re.compile(r'Smart Farm v1\.0', re.IGNORECASE), 'AgroSense v1.0'),
    (re.compile(r'Smart Farm Logo', re.IGNORECASE), 'AgroSense Logo'),
    (re.compile(r'Smart Farm —', re.IGNORECASE), 'AgroSense —'),
    (re.compile(r'— Smart Farm', re.IGNORECASE), '— AgroSense'),
    (re.compile(r'Smart Farm IoT', re.IGNORECASE), 'AgroSense IoT'),
    (re.compile(r'Welcome to Smart Farm', re.IGNORECASE), 'Welcome to AgroSense'),
    (re.compile(r'Loading Smart Farm', re.IGNORECASE), 'Loading AgroSense'),
    (re.compile(r'>Smart Farm<', re.IGNORECASE), '>AgroSense<'),
    (re.compile(r'Smart Farm', re.IGNORECASE), 'AgroSense')
]

for root, dirs, files in os.walk('d:\\smart_farming'):
    if '.firebase' in root or '.git' in root or 'node_modules' in root:
        continue
    for file in files:
        if any(file.endswith(ext) for ext in extensions):
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
            except Exception as e:
                print(f"Error reading {filepath}: {e}")
                continue
            
            new_content = content
            for pattern, replacement in replacements:
                new_content = pattern.sub(replacement, new_content)
                
            if content != new_content:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                print(f"Updated {filepath}")
