import urllib.request
import os

base_url = "https://smart-farming-3d1f2.web.app/"
files_to_download = [
    "index.html",
    "login.html",
    "dashboard.html",
    "pages/account.html",
    "pages/charts.html",
    "pages/history.html",
    "pages/live-monitoring.html",
    "pages/pump-control.html",
    "pages/reports.html",
    "pages/sensors.html",
    "pages/settings.html"
]

base_dir = "d:/smart_farming"

for file_path in files_to_download:
    url = base_url + file_path
    local_path = os.path.join(base_dir, file_path)
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    
    try:
        print(f"Downloading {url} to {local_path}...")
        urllib.request.urlretrieve(url, local_path)
        print(f"Success: {local_path}")
    except Exception as e:
        print(f"Failed to download {url}: {e}")
