/*
  ==============================================================================
  AgroSense System — ESP32 Arduino Firmware  (OLED Edition)
  ==============================================================================
  Hardware GPIO Mapping:
    GPIO34 → Soil Moisture Sensor (Analog)
    GPIO35 → Rain Sensor         (Analog)
    GPIO33 → Water Level Sensor  (Analog)
    GPIO32 → LDR Light Sensor    (Analog)
    GPIO27 → DS18B20 Soil Temp   (OneWire)
    GPIO4  → DHT11 Temp/Humidity
    GPIO26 → Relay (Water Pump)
    GPIO21 → OLED/I2C SDA
    GPIO22 → OLED/I2C SCL

  Firebase Realtime Database Keys (must match web dashboard):
    SmartFarming/Sensors/temperature     ← DHT11
    SmartFarming/Sensors/humidity        ← DHT11
    SmartFarming/Sensors/soilMoisture    ← GPIO34
    SmartFarming/Sensors/soilTemp        ← DS18B20 GPIO27
    SmartFarming/Sensors/rainLevel       ← GPIO35
    SmartFarming/Sensors/lightLevel      ← LDR GPIO32
    SmartFarming/Sensors/waterLevel      ← GPIO33
    SmartFarming/Pump/status             ← bool
    SmartFarming/Pump/mode               ← "manual"|"auto"
    SmartFarming/Pump/runtime            ← seconds
    SmartFarming/Device/online           ← bool
    SmartFarming/Device/wifiRSSI         ← dBm
    SmartFarming/Device/ipAddress        ← string
    SmartFarming/Device/uptime           ← seconds
    SmartFarming/Device/lastUpdate       ← epoch ms

  Libraries Required (install via Arduino Library Manager):
    ▸ Firebase ESP Client    — mobizt/Firebase-ESP-Client
    ▸ DHT sensor library     — adafruit/DHT-sensor-library
    ▸ Adafruit Unified Sensor— adafruit/Adafruit_Sensor
    ▸ DallasTemperature      — milesburton/Arduino-Temperature-Control-Library
    ▸ OneWire                — PaulStoffregen/OneWire
    ▸ Adafruit SSD1306       — adafruit/Adafruit_SSD1306
    ▸ Adafruit GFX Library   — adafruit/Adafruit-GFX-Library
  ==============================================================================
*/

#include <WiFi.h>
#include <time.h>
#include <FirebaseESP32.h>
#include <DHT.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>

// ─── WiFi / Firebase CREDENTIALS ─────────────────────────────────────────────
#define WIFI_SSID      "masum"
#define WIFI_PASSWORD  "123456789"
#define API_KEY        "AIzaSyAgMzY-3nDHQ2BJkPDkY7dUiGSDV6wefag"
#define DATABASE_URL   "https://smart-farming-3d1f2-default-rtdb.asia-southeast1.firebasedatabase.app"
#define USER_EMAIL     "agrosense@gmail.com"
#define USER_PASSWORD  "agrosense123"

// NTP settings (for correct epoch timestamp)
#define NTP_SERVER     "pool.ntp.org"
#define GMT_OFFSET_SEC 0   // MUST be 0 (UTC) to match web frontend Date.now()
#define DST_OFFSET_SEC 0

// ─── GPIO PINS ────────────────────────────────────────────────────────────────
#define PIN_SOIL_MOISTURE  34
#define PIN_RAIN           35
#define PIN_WATER_LEVEL    33
#define PIN_LDR            32
#define PIN_DS18B20        27
#define PIN_DHT11          4
#define PIN_RELAY_PUMP     26
#define OLED_SDA           21
#define OLED_SCL           22

// ─── OLED CONFIG ──────────────────────────────────────────────────────────────
#define OLED_WIDTH   128
#define OLED_HEIGHT   64
#define OLED_ADDR   0x3C    // Try 0x3D if display blank

// ─── ADC CALIBRATION ─────────────────────────────────────────────────────────
// All resistive sensors: HIGH ADC = dry/no-contact, LOW ADC = wet/submerged
// ► To calibrate: read Serial Monitor "raw:" values in dry and wet states
//
// Soil Moisture  (GPIO34): dry air ≈ 3800, wet soil ≈ 1200
#define SOIL_DRY     3800
#define SOIL_WET     1200

// Rain Sensor    (GPIO35): dry PCB ≈ 4000, submerged ≈ 800
#define RAIN_DRY     4000
#define RAIN_WET      800

// Water Level    (GPIO33): no water/floating ≈ 3900, full tank ≈ 600
// INVERTED: high ADC = empty (0%), low ADC = full (100%)
#define WATER_EMPTY  3900
#define WATER_FULL    600

// LDR Light      (GPIO32): dark ≈ 4095, bright light ≈ 0
#define LDR_DARK     4095
#define LDR_BRIGHT      0
#define LUX_MAX      1200

// ─── TIMING ───────────────────────────────────────────────────────────────────
#define SENSOR_INTERVAL   2000    // ms — read & push sensor data
#define DEVICE_INTERVAL  10000    // ms — push device telemetry
#define OLED_INTERVAL     3000    // ms — cycle OLED display page
#define WIFI_CHECK_MS     8000    // ms — WiFi watchdog interval (8s for fast recovery)
#define PUMP_INTERVAL     1000    // ms — check pump commands

// ─── SENSOR OBJECTS ───────────────────────────────────────────────────────────
DHT               dht(PIN_DHT11, DHT11);
OneWire           oneWire(PIN_DS18B20);
DallasTemperature ds18b20(&oneWire);
Adafruit_SSD1306  oled(OLED_WIDTH, OLED_HEIGHT, &Wire, -1);

// ─── FIREBASE OBJECTS ─────────────────────────────────────────────────────────
FirebaseData   fbdo;
FirebaseAuth   fbauth;
FirebaseConfig fbconfig;

// ─── STATE ────────────────────────────────────────────────────────────────────
unsigned long lastSensorMs  = 0;
unsigned long lastDeviceMs  = 0;
unsigned long lastOledMs    = 0;
unsigned long lastWifiCheck = 0;
unsigned long lastPumpMs    = 0;
unsigned long startMs       = 0;
unsigned long uptimeSeconds = 0;
bool          wifiJustReconnected = false;  // flag: push immediately after reconnect
int           oledPage      = 0;
bool          pumpStatus    = false;
String        pumpMode      = "manual";
bool          firebaseInited = false;

// ─── SENSOR READINGS ─────────────────────────────────────────────────────────
float tempC         = 0;
float humidPct      = 0;
float soilMoistPct  = 0;
float soilTempC     = 0;
float rainLevelPct  = 0;
float lightLux      = 0;
float waterLevelPct = 0;

// ─────────────────────────────────────────────────────────────────────────────
// HELPER: mapFloat — maps float value from one range to another
// ─────────────────────────────────────────────────────────────────────────────
float mapFloat(float val, float inMin, float inMax, float outMin, float outMax) {
  float result = (val - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
  return constrain(result, min(outMin, outMax), max(outMin, outMax));
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPER: epochSec — returns current epoch time in seconds (from NTP)
// Returns millis() / 1000 as fallback if NTP not synced
// ─────────────────────────────────────────────────────────────────────────────
long epochSec() {
  struct timeval tv;
  gettimeofday(&tv, nullptr);
  if (tv.tv_sec < 1000000000LL) {
    // NTP not synced — use millis as approximate seconds
    return millis() / 1000;
  }
  return tv.tv_sec;
}

// ─────────────────────────────────────────────────────────────────────────────
// OLED HELPER: show full-screen status message
// ─────────────────────────────────────────────────────────────────────────────
void oledStatus(const String& line1, const String& line2 = "", const String& line3 = "") {
  oled.clearDisplay();
  oled.setTextColor(SSD1306_WHITE);
  oled.setTextSize(1);
  oled.setCursor(0, 0);  oled.println(line1);
  oled.setCursor(0, 20); oled.println(line2);
  oled.setCursor(0, 40); oled.println(line3);
  oled.display();
}

// ─────────────────────────────────────────────────────────────────────────────
// WiFi CONNECT — up to 3 attempts × 10 s each
// Returns true if connected
// ─────────────────────────────────────────────────────────────────────────────
bool connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return true;

  Serial.println("\n[WiFi] Connecting to: " + String(WIFI_SSID));
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(false);
  delay(200);

  for (int attempt = 1; attempt <= 3; attempt++) {
    Serial.printf("[WiFi] Attempt %d/3...\n", attempt);
    oledStatus("WiFi Connecting...",
               "SSID: " + String(WIFI_SSID),
               "Attempt " + String(attempt) + "/3");

    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    unsigned long t = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t < 10000) {  // 10s per attempt
      delay(300);
      Serial.print(".");
    }
    Serial.println();

    if (WiFi.status() == WL_CONNECTED) {
      String ip = WiFi.localIP().toString();
      int rssi   = WiFi.RSSI();
      Serial.printf("[WiFi] Connected! IP: %s  RSSI: %d dBm\n", ip.c_str(), rssi);

      // Sync NTP time (Crucial for Firebase SSL/Token)
      configTime(GMT_OFFSET_SEC, DST_OFFSET_SEC, NTP_SERVER);
      Serial.println("[NTP] Time sync requested...");
      
      // Wait until time is synced (epoch > 100000)
      time_t now = time(nullptr);
      int ntpRetry = 0;
      while (now < 100000 && ntpRetry < 50) {
        delay(100);
        now = time(nullptr);
        ntpRetry++;
      }
      if (now > 100000) Serial.println("[NTP] Time synced successfully!");
      else Serial.println("[NTP] Time sync timeout, proceeding anyway.");

      oled.clearDisplay();
      oled.setTextSize(1); oled.setTextColor(SSD1306_WHITE);
      oled.setCursor(0,  0); oled.println("  WiFi Connected!");
      oled.setCursor(0, 16); oled.println("IP: " + ip);
      oled.setCursor(0, 32); oled.println("RSSI: " + String(rssi) + " dBm");
      oled.setCursor(0, 48); oled.println("AgroSense Online");
      oled.display();
      delay(1000);  // short delay — don't block too long
      wifiJustReconnected = true;  // trigger immediate push
      return true;
    }

    Serial.printf("[WiFi] Attempt %d failed. Waiting 2s...\n", attempt);
    WiFi.disconnect(true);
    delay(2000);
  }

  Serial.println("[WiFi] All attempts failed. Running OFFLINE.");
  oledStatus("WiFi FAILED!", "Running Offline", "Sensors Active");
  delay(2000);
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// FIREBASE INIT
// ─────────────────────────────────────────────────────────────────────────────
void initFirebase() {
  if (WiFi.status() != WL_CONNECTED) return;
  fbconfig.api_key               = API_KEY;
  fbconfig.database_url          = DATABASE_URL;
  fbauth.user.email              = USER_EMAIL;
  fbauth.user.password           = USER_PASSWORD;
  fbconfig.token_status_callback = tokenStatusCallback;
  Firebase.begin(&fbconfig, &fbauth);
  Firebase.reconnectWiFi(true);
  firebaseInited = true;
  Serial.println("[Firebase] Initialized.");
}

// ─────────────────────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n============================================");
  Serial.println("     AgroSense Smart Farming  v2.0");
  Serial.println("============================================");

  // Pump relay — ensure OFF at boot
  pinMode(PIN_RELAY_PUMP, OUTPUT);
  digitalWrite(PIN_RELAY_PUMP, HIGH); // Active-LOW relay, HIGH means OFF

  // Sensors
  dht.begin();
  ds18b20.begin();

  // OLED init
  Wire.begin(OLED_SDA, OLED_SCL);
  if (!oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("[OLED] Not found at 0x3C! Check wiring or try 0x3D.");
    // Continue without OLED — non-fatal
  } else {
    oled.clearDisplay();
    oled.setTextSize(2); oled.setTextColor(SSD1306_WHITE);
    oled.setCursor(10, 10); oled.println("AgroSense");
    oled.setTextSize(1);
    oled.setCursor(20, 40); oled.println("Smart Farming v2");
    oled.display();
    delay(2000);
  }

  // WiFi — connect with auto-retry
  bool wifiOK = connectWiFi();

  // Firebase — only if WiFi is up
  if (wifiOK) {
    initFirebase();
    delay(2000);  // let auth token settle
    if (Firebase.ready()) {
      Firebase.setBool(fbdo,   "SmartFarming/Device/online",    true);
      Firebase.setString(fbdo, "SmartFarming/Device/ipAddress", WiFi.localIP().toString());
      Firebase.setInt(fbdo,    "SmartFarming/Device/uptime",    0);
      Firebase.setInt(fbdo,    "SmartFarming/Device/wifiRSSI",  WiFi.RSSI());
      Serial.println("[Firebase] Initial device status OK.");
    }
  } else {
    Serial.println("[Firebase] Skipped — no WiFi.");
  }

  startMs = millis();
  Serial.println("[SmartFarm] Loop started. Sensor interval: " + String(SENSOR_INTERVAL) + "ms");
}

// ─────────────────────────────────────────────────────────────────────────────
// LOOP
// ─────────────────────────────────────────────────────────────────────────────
void loop() {
  unsigned long now = millis();
  uptimeSeconds = (now - startMs) / 1000;

  // ── WiFi watchdog: check & reconnect every 8 s ───────────────────────────
  if (now - lastWifiCheck >= WIFI_CHECK_MS) {
    lastWifiCheck = now;
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println("[WiFi] Lost connection! Reconnecting...");
      bool ok = connectWiFi();
      if (ok && !firebaseInited) initFirebase();
    }
  }

  // ── Immediate push after reconnect ───────────────────────────────────────
  if (wifiJustReconnected && WiFi.status() == WL_CONNECTED) {
    // Let Firebase-ESP-Client handle the reconnection internally.
    // Wait up to 10 seconds for auth token to become ready
    unsigned long fbWait = millis();
    while (!Firebase.ready() && millis() - fbWait < 10000) {
      delay(300);
    }
    
    if (Firebase.ready()) {
      wifiJustReconnected = false;
      Serial.println("[WiFi] Reconnected + Firebase ready — pushing immediately.");
      readAllSensors();
      pushSensors();
      pushDevice();
      lastSensorMs = now;
      lastDeviceMs = now;
    } else {
      // Still not ready — try next cycle
      Serial.println("[Firebase] Token still not ready, will retry normally in loop.");
      wifiJustReconnected = false; // Don't block the loop forever
    }
  }

  // ── Read + push sensors every SENSOR_INTERVAL ────────────────────────────
  if (now - lastSensorMs >= SENSOR_INTERVAL) {
    lastSensorMs = now;
    readAllSensors();
    if (WiFi.status() == WL_CONNECTED && Firebase.ready()) pushSensors();
  }

  // ── Push device telemetry every DEVICE_INTERVAL ──────────────────────────
  if (now - lastDeviceMs >= DEVICE_INTERVAL) {
    lastDeviceMs = now;
    if (WiFi.status() == WL_CONNECTED && Firebase.ready()) {
      pushDevice();
    }
  }

  // ── Check pump commands every PUMP_INTERVAL ──────────────────────────────
  if (now - lastPumpMs >= PUMP_INTERVAL) {
    lastPumpMs = now;
    if (WiFi.status() == WL_CONNECTED && Firebase.ready()) {
      checkPumpCommand();
    }
  }

  // ── Cycle OLED display every OLED_INTERVAL ───────────────────────────────
  if (now - lastOledMs >= OLED_INTERVAL) {
    lastOledMs = now;
    updateOLED();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// READ ALL SENSORS
// ─────────────────────────────────────────────────────────────────────────────
void readAllSensors() {

  // ── DHT11: Temperature & Humidity (retry up to 3× on NaN) ─────────────────
  float t = NAN, h = NAN;
  for (int retry = 0; retry < 3 && (isnan(t) || isnan(h)); retry++) {
    if (retry > 0) delay(300);
    t = dht.readTemperature();
    h = dht.readHumidity();
  }
  if (!isnan(t) && t >= -10.0 && t <= 80.0) tempC    = t;
  if (!isnan(h) && h >=   0.0 && h <= 100.0) humidPct = h;

  // ── DS18B20: Soil Temperature ─────────────────────────────────────────────
  ds18b20.requestTemperatures();
  float st = ds18b20.getTempCByIndex(0);
  if (st != DEVICE_DISCONNECTED_C && st >= -55.0 && st <= 125.0) soilTempC = st;

  // ── Analog sensors: average 5 samples for noise reduction ─────────────────
  long rawSoil = 0, rawRain = 0, rawWater = 0, rawLight = 0;
  for (int i = 0; i < 5; i++) {
    rawSoil  += analogRead(PIN_SOIL_MOISTURE);
    rawRain  += analogRead(PIN_RAIN);
    rawWater += analogRead(PIN_WATER_LEVEL);
    rawLight += analogRead(PIN_LDR);
    delay(10);
  }
  rawSoil /= 5; rawRain /= 5; rawWater /= 5; rawLight /= 5;

  // ── Map ADC → meaningful units ────────────────────────────────────────────
  soilMoistPct  = mapFloat(rawSoil,  SOIL_DRY,    SOIL_WET,    0, 100);
  rainLevelPct  = mapFloat(rawRain,  RAIN_DRY,    RAIN_WET,    0, 100);
  waterLevelPct = mapFloat(rawWater, WATER_EMPTY, WATER_FULL,  0, 100);  // inverted
  lightLux      = mapFloat(rawLight, LDR_DARK,    LDR_BRIGHT,  0, LUX_MAX);

  // ── Debug output (raw values help you calibrate) ──────────────────────────
  Serial.printf(
    "[Sensors] T:%.1f°C H:%.0f%% Soil:%.0f%%(r:%ld) SoilT:%.1f°C "
    "Rain:%.0f%%(r:%ld) Light:%.0flux(r:%ld) Water:%.0f%%(r:%ld)\n",
    tempC, humidPct,
    soilMoistPct, rawSoil, soilTempC,
    rainLevelPct, rawRain,
    lightLux,     rawLight,
    waterLevelPct,rawWater
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PUSH SENSORS → FIREBASE
// Key names MUST match web dashboard SENSOR_CONFIG IDs exactly
// ─────────────────────────────────────────────────────────────────────────────
void pushSensors() {
  FirebaseJson sensors;
  sensors.set("temperature",  tempC);
  sensors.set("humidity",     humidPct);
  sensors.set("soilMoisture", soilMoistPct);
  sensors.set("soilTemp",     soilTempC);     // web expects "soilTemp"
  sensors.set("rainLevel",    rainLevelPct);  // web expects "rainLevel"
  sensors.set("lightLevel",   lightLux);      // web expects "lightLevel"
  sensors.set("waterLevel",   waterLevelPct);

  if (!Firebase.updateNode(fbdo, "SmartFarming/Sensors", sensors)) {
    Serial.println("[Firebase] Sensor push error: " + fbdo.errorReason());
    return;
  }

  // Epoch timestamp in seconds (from NTP if synced, else millis/1000)
  Firebase.setInt(fbdo, "SmartFarming/Device/lastUpdate", (int)epochSec());
}

// ─────────────────────────────────────────────────────────────────────────────
// PUSH DEVICE TELEMETRY → FIREBASE
// ─────────────────────────────────────────────────────────────────────────────
void pushDevice() {
  FirebaseJson device;
  device.set("online",     true);
  device.set("uptime",     (int)uptimeSeconds);
  device.set("wifiRSSI",   (int)WiFi.RSSI());
  device.set("ipAddress",  WiFi.localIP().toString());
  device.set("lastUpdate", (int)epochSec());

  if (!Firebase.updateNode(fbdo, "SmartFarming/Device", device)) {
    Serial.println("[Firebase] Device push error: " + fbdo.errorReason());
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CHECK PUMP COMMAND FROM FIREBASE
// ─────────────────────────────────────────────────────────────────────────────
void checkPumpCommand() {
  // Read mode first
  if (Firebase.getString(fbdo, "SmartFarming/Pump/mode")) {
    pumpMode = fbdo.stringData();
  }

  if (pumpMode == "auto") {
    // Auto: pump ON when soil moisture < 30%
    bool shouldRun = (soilMoistPct < 30.0f);
    if (shouldRun != pumpStatus) {
      pumpStatus = shouldRun;
      digitalWrite(PIN_RELAY_PUMP, pumpStatus ? LOW : HIGH); // Active-LOW relay
      Firebase.setBool(fbdo, "SmartFarming/Pump/status", pumpStatus);
      Serial.printf("[AutoPump] Soil=%.0f%% → Pump %s\n",
                    soilMoistPct, pumpStatus ? "ON" : "OFF");
    }
  } else {
    // Manual: obey Firebase command
    if (Firebase.getBool(fbdo, "SmartFarming/Pump/status")) {
      bool cmd = fbdo.boolData();
      if (cmd != pumpStatus) {
        pumpStatus = cmd;
        digitalWrite(PIN_RELAY_PUMP, pumpStatus ? LOW : HIGH); // Active-LOW relay
        Serial.printf("[Pump] Manual → %s\n", pumpStatus ? "ON" : "OFF");
      }
    }
  }

  // Runtime counter
  static unsigned long pumpStartMs = 0;
  if (pumpStatus && pumpStartMs == 0) pumpStartMs = millis();
  if (!pumpStatus) pumpStartMs = 0;
  if (pumpStatus && pumpStartMs > 0) {
    int runtime = (int)((millis() - pumpStartMs) / 1000);
    Firebase.setInt(fbdo, "SmartFarming/Pump/runtime", runtime);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// OLED DISPLAY — cycles through 5 pages
// ─────────────────────────────────────────────────────────────────────────────
void drawLabel(int x, int y, const String& label, const String& val, const String& unit) {
  oled.setCursor(x, y);
  oled.setTextSize(1); oled.setTextColor(SSD1306_WHITE);
  oled.print(label + ": ");
  oled.setTextSize(1);
  oled.print(val);
  oled.print(unit);
}

void updateOLED() {
  oled.clearDisplay();

  // Header bar
  oled.fillRect(0, 0, OLED_WIDTH, 10, SSD1306_WHITE);
  oled.setTextColor(SSD1306_BLACK);
  oled.setTextSize(1);

  switch (oledPage) {
    // ── Page 0: Temperature & Humidity ──────────────────────────────────────
    case 0:
      oled.setCursor(28, 1); oled.print("TEMP & HUMIDITY");
      oled.setTextColor(SSD1306_WHITE);
      oled.setTextSize(2);
      oled.setCursor(10, 14); oled.printf("%.1f", tempC);
      oled.setTextSize(1); oled.print(" C");
      oled.setTextSize(2);
      oled.setCursor(10, 38); oled.printf("%.0f", humidPct);
      oled.setTextSize(1); oled.print(" %RH");
      break;

    // ── Page 1: Soil Moisture & Soil Temperature ────────────────────────────
    case 1:
      oled.setCursor(22, 1); oled.print("SOIL CONDITIONS");
      oled.setTextColor(SSD1306_WHITE);
      oled.setTextSize(1);
      oled.setCursor(0, 14); oled.printf("Moisture : %.0f %%", soilMoistPct);
      oled.setCursor(0, 26); oled.printf("Soil Temp: %.1f C",  soilTempC);
      // Mini progress bar for soil moisture
      oled.drawRect(0, 42, 128, 10, SSD1306_WHITE);
      oled.fillRect(2, 44, (int)(soilMoistPct * 1.24f), 6, SSD1306_WHITE);
      oled.setCursor(0, 55); oled.printf("Dry 0%%        100%% Wet");
      break;

    // ── Page 2: Rain & Light ────────────────────────────────────────────────
    case 2:
      oled.setCursor(30, 1); oled.print("RAIN & LIGHT");
      oled.setTextColor(SSD1306_WHITE);
      oled.setTextSize(1);
      oled.setCursor(0, 14); oled.printf("Rain  : %.0f %%",     rainLevelPct);
      oled.setCursor(0, 26); oled.printf("Light : %.0f lux",    lightLux);
      // Mini progress bar for rain
      oled.drawRect(0, 42, 128, 10, SSD1306_WHITE);
      oled.fillRect(2, 44, (int)(rainLevelPct * 1.24f), 6, SSD1306_WHITE);
      oled.setCursor(0, 55); oled.print("No Rain     Heavy Rain");
      break;

    // ── Page 3: Water Level & Pump ──────────────────────────────────────────
    case 3:
      oled.setCursor(24, 1); oled.print("WATER & PUMP");
      oled.setTextColor(SSD1306_WHITE);
      oled.setTextSize(1);
      oled.setCursor(0, 14); oled.printf("Water : %.0f %%",   waterLevelPct);
      oled.setCursor(0, 26); oled.printf("Pump  : %s",        pumpStatus ? "RUNNING" : "OFF");
      oled.setCursor(0, 38); oled.printf("Mode  : %s",        pumpMode.c_str());
      // Water level bar
      oled.drawRect(0, 50, 128, 10, SSD1306_WHITE);
      oled.fillRect(2, 52, (int)(waterLevelPct * 1.24f), 6, SSD1306_WHITE);
      break;

    // ── Page 4: Device Status ───────────────────────────────────────────────
    case 4: {
      oled.setCursor(28, 1); oled.print("DEVICE STATUS");
      oled.setTextColor(SSD1306_WHITE);
      oled.setTextSize(1);
      bool wifiUp = (WiFi.status() == WL_CONNECTED);
      oled.setCursor(0, 14); oled.printf("WiFi  : %s", wifiUp ? WiFi.localIP().toString().c_str() : "Offline");
      oled.setCursor(0, 26); oled.printf("RSSI  : %d dBm",  wifiUp ? WiFi.RSSI() : 0);
      oled.setCursor(0, 38); oled.printf("Uptime: %lu s",   uptimeSeconds);
      oled.setCursor(0, 50); oled.printf("FB    : %s", Firebase.ready() ? "Connected" : "Offline");
      break;
    }
  }

  oled.display();
  oledPage = (oledPage + 1) % 5;
}
